"""Long moves must not run pigpio out of wave memory ("No more OOL for waveform").

The fake below copies pigpio's real wave allocator (pigpio.c v79: gpioWaveCreate,
gpioWaveCreatePad, gpioWaveDelete, waveCBsOOLs): fixed pools of control blocks
and OOL words, reuse of a deleted wave only on an exact size match, and garbage
collection only when the top wave is deleted.
"""
import os
import sys
import threading
import types

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import numpy as np

# --- pigpio constants (pigpio.c / pigpio.h, v79) ---------------------------
PAGES_PER_BLOCK, PI_WAVE_BLOCKS, PI_WAVE_COUNT_PAGES = 53, 4, 10
CBS_PER_OPAGE, OOL_PER_OPAGE = 118, 79
DMAO_PAGES = PAGES_PER_BLOCK * PI_WAVE_BLOCKS
NUM_WAVE_CBS = DMAO_PAGES * CBS_PER_OPAGE          # 25016
NUM_WAVE_OOL = DMAO_PAGES * OOL_PER_OPAGE          # 16748
PI_MAX_WAVES = 250


class error(Exception):
    pass


class pulse:
    def __init__(self, on, off, delay):
        self.gpio_on, self.gpio_off, self.delay = on, off, delay


class Wave:
    def __init__(self, **kw):
        self.__dict__.update(kw)
        self.deleted = False


class FakePi:
    connected = True
    version = 79                         # set < 74 to emulate a daemon without wave_create_and_pad

    def __init__(self, *a):
        self.info: list[Wave] = []
        self.count = 0
        self.bot_cb = PI_WAVE_COUNT_PAGES * CBS_PER_OPAGE
        self.bot_ool = PI_WAVE_COUNT_PAGES * OOL_PER_OPAGE
        self.top_ool = NUM_WAVE_OOL
        self.pend = []
        self.content = {}
        self.played = []                 # pulse lists in the order they were transmitted
        self.cur = None
        self.max_live = 0

    # simple IO
    def set_mode(self, *a): pass
    def write(self, *a): pass
    def read(self, *a): return 1
    def set_pull_up_down(self, *a): pass
    def set_glitch_filter(self, *a): pass
    def set_servo_pulsewidth(self, *a): pass
    def stop(self): pass
    def get_pigpio_version(self): return self.version
    def wave_get_max_cbs(self): return NUM_WAVE_CBS

    # waves
    def wave_clear(self):
        self.__init__()

    def wave_add_generic(self, p):
        self.pend.extend(p)
        return len(self.pend)

    def _needs(self):
        cb, bool_, tool = 1, 0, 0                    # delay cb at start of DMA
        for p in self.pend:
            bool_ += (p.gpio_on != 0) + (p.gpio_off != 0)
            cb += (p.gpio_on != 0 or p.gpio_off != 0)
            cb += 1 if p.delay else 0                # DMA secondary channel 6: one CB per delay
        return cb, bool_, tool

    def _alloc(self, cb, bool_, tool):
        wid = -1
        for i in range(self.count):
            w = self.info[i]
            if w.deleted and (w.cb, w.bool, w.tool) == (cb, bool_, tool):
                wid = i
                break
        if wid == -1:
            if cb + self.bot_cb > NUM_WAVE_CBS:
                raise error("No more CBs for waveform")
            if bool_ + self.bot_ool > self.top_ool - tool:
                raise error("No more OOL for waveform")
            if self.count >= PI_MAX_WAVES:
                raise error("No more waveform ids")
            wid = self.count
            self.count += 1
            w = Wave(bot_cb=self.bot_cb, bot_ool=self.bot_ool, top_ool=self.top_ool, cb=cb, bool=bool_, tool=tool)
            if wid < len(self.info):
                self.info[wid] = w
            else:
                self.info.append(w)
            self.bot_cb += cb
            self.bot_ool += bool_
            self.top_ool -= tool
        self.info[wid].deleted = False
        self.content[wid] = self.pend
        self.pend = []
        self.max_live = max(self.max_live, sum(1 for i in range(self.count) if not self.info[i].deleted))
        return wid

    def wave_create(self):
        if not self.pend:
            raise error("attempt to create an empty waveform")
        return self._alloc(*self._needs())

    def wave_create_and_pad(self, percent):
        if self.version < 74:
            raise error("unknown command")
        if not self.pend:
            raise error("attempt to create an empty waveform")
        cb, bool_, tool = self._needs()
        pcb = (NUM_WAVE_CBS - PI_WAVE_COUNT_PAGES * CBS_PER_OPAGE) * percent // 100
        pool = (NUM_WAVE_OOL - PI_WAVE_COUNT_PAGES * OOL_PER_OPAGE) * percent // 100
        if cb > pcb:
            raise error("No more CBs for waveform")
        if bool_ > pool:
            raise error("No more OOL for waveform")
        return self._alloc(pcb, pool, 0)

    def wave_delete(self, wid):
        if wid >= self.count or self.info[wid].deleted:
            raise error("bad wave id")
        self.info[wid].deleted = True
        if wid == self.count - 1:
            while wid > 0 and self.info[wid - 1].deleted:
                wid -= 1
            w = self.info[wid]
            self.bot_cb, self.bot_ool, self.top_ool = w.bot_cb, w.bot_ool, w.top_ool
            self.count = wid

    def _send(self, wid):
        assert wid < self.count and not self.info[wid].deleted
        self.played.append(self.content[wid])
        self.cur = wid

    def wave_send_using_mode(self, wid, mode): self._send(wid)
    def wave_send_once(self, wid): self._send(wid)
    def wave_tx_at(self): return self.cur if self.cur is not None else 9999
    def wave_tx_busy(self): return False
    def wave_tx_stop(self): pass


fake = types.ModuleType("pigpio")
fake.pulse, fake.pi, fake.error = pulse, FakePi, error
fake.OUTPUT, fake.INPUT, fake.PUD_UP, fake.PUD_DOWN = 1, 0, 2, 1
fake.WAVE_MODE_ONE_SHOT, fake.WAVE_MODE_ONE_SHOT_SYNC = 0, 2
sys.modules["pigpio"] = fake

from plotter.config import Config  # noqa: E402
from plotter.hardware import PigpioDriver, DriverError  # noqa: E402
from plotter.kinematics import Kinematics  # noqa: E402
from plotter.planner import plan_job, motion_from_draw, build_ticks  # noqa: E402


def _use_fake():
    sys.modules["pigpio"] = fake           # other test files install their own fake pigpio


def long_varied_ticks(cfg):
    """A spiral of many turns: step rates and directions change all the way through."""
    kin = Kinematics(cfg)
    t = np.linspace(0, 16 * np.pi, 4000)
    rr = 15 + 30 * t / t[-1]
    spiral = np.c_[130 + rr * np.cos(t), 110 + rr * np.sin(t)]
    plan = plan_job([spiral], kin, cfg, (0, 0))
    dp = [o[1] for o in plan.ops if o[0] == "draw"][0]
    return build_ticks(motion_from_draw(dp), (1, -1), (0, 0), cfg.v["motion.backlash_rate_hz"])


def varied_ticks(n_segments=400, seed=1):
    """Short segments at mixed rates and directions, like jogs, corners and slow curves."""
    from plotter.planner import Ticks, TICK_US
    rng = np.random.default_rng(seed)
    gaps, masks, da, db = [], [], [], []
    for _ in range(n_segments):
        n = int(rng.integers(30, 1500))
        g = int(rng.integers(70, 3000)) // TICK_US * TICK_US
        gaps.append(np.full(n, g))
        masks.append(rng.choice([1, 2, 3], n))
        da.append(np.full(n, rng.choice([-1, 1])))
        db.append(np.full(n, rng.choice([-1, 1])))
    t = np.cumsum(np.concatenate(gaps)).astype(np.int64)
    mask = np.concatenate(masks).astype(np.uint8)
    dir_a = np.concatenate(da).astype(np.int8)
    dir_b = np.concatenate(db).astype(np.int8)
    return Ticks(t, mask, dir_a, dir_b, (0, 0), float(t[-1]) / 1e6, (int(dir_a[-1]), int(dir_b[-1])))


def slowdown_ticks(n=12000, g0=70.0, growth=1.0004):
    """One long deceleration: the step gap keeps growing, so every wave chunk has a different size."""
    from plotter.planner import Ticks, TICK_US
    g = np.maximum(np.rint(g0 * growth ** np.arange(n) / TICK_US) * TICK_US, TICK_US).astype(np.int64)
    t = np.cumsum(g)
    one = np.ones(n, np.int8)
    return Ticks(t, np.full(n, 3, np.uint8), one, -one, (0, 0), float(t[-1]) / 1e6, (1, -1))


def test_slowdown_does_not_exhaust_wave_memory():
    _use_fake()
    cfg = Config({"home.use_switches": False})
    tk = slowdown_ticks()
    drv = PigpioDriver(cfg)
    assert drv.run(tk, threading.Event()) == len(tk)
    pi = drv.pi
    na, nb = decode(pi, drv, tk)
    assert na == nb == len(tk)
    assert pi.max_live <= 2, pi.max_live
    print(f"slowdown: {len(tk)} step events over {tk.duration_s:.0f} s, {len(pi.played) - 1} waves, at most {pi.max_live} alive")


def test_varied_move_does_not_exhaust_wave_memory():
    _use_fake()
    cfg = Config({"home.use_switches": False})
    tk = varied_ticks()
    drv = PigpioDriver(cfg)
    reached = drv.run(tk, threading.Event())
    pi = drv.pi
    assert reached == len(tk)
    na, nb = decode(pi, drv, tk)
    assert na == int(((tk.mask & 1) > 0).sum()) and nb == int(((tk.mask & 2) > 0).sum())
    assert pi.max_live <= 2, pi.max_live
    print(f"varied: {len(tk)} step events, {len(pi.played) - 1} waves, at most {pi.max_live} alive")


def decode(pi, drv, tk):
    """Count STEP rising edges per motor in what was actually transmitted."""
    state, na, nb = 0, 0, 0
    for wave in pi.played[:-1]:                     # last one is the STEP-low cleanup
        for p in wave:
            new = (state | p.gpio_on) & ~p.gpio_off
            rise = new & ~state
            na += bool(rise & drv.stepA)
            nb += bool(rise & drv.stepB)
            state = new
    return na, nb


def test_long_move_does_not_exhaust_wave_memory():
    _use_fake()
    cfg = Config({"home.use_switches": False, "screw.length_mm": 260, "screw.unusable_mm": 20})
    tk = long_varied_ticks(cfg)
    drv = PigpioDriver(cfg)
    reached = drv.run(tk, threading.Event())
    pi = drv.pi
    assert reached == len(tk)
    na, nb = decode(pi, drv, tk)
    assert na == int(((tk.mask & 1) > 0).sum()) and nb == int(((tk.mask & 2) > 0).sum())
    assert pi.max_live <= 2, pi.max_live
    print(f"{len(tk)} step events, {len(pi.played) - 1} waves streamed, at most {pi.max_live} alive, steps A {na} B {nb}")
    # run it again on the same daemon: nothing may have leaked
    drv.run(tk, threading.Event())
    assert pi.count == 0, f"{pi.count} waves left allocated"


def test_old_daemon_gets_a_clear_message():
    _use_fake()
    FakePi.version = 71
    try:
        drv = PigpioDriver(Config({"home.use_switches": False}))
        assert not drv.padded
        try:
            drv.run(slowdown_ticks(n=300), threading.Event())    # short moves still work
        except DriverError as e:
            raise AssertionError(f"short move failed on old daemon: {e}")
        tk = slowdown_ticks()
        try:
            drv.run(tk, threading.Event())
        except DriverError as e:
            assert "pigpio" in str(e) and "install.sh" in str(e), e
            print("old daemon message:", e)
        else:
            raise AssertionError("expected DriverError on an old pigpio daemon")
    finally:
        FakePi.version = 79


if __name__ == "__main__":
    test_slowdown_does_not_exhaust_wave_memory()
    test_varied_move_does_not_exhaust_wave_memory()
    test_long_move_does_not_exhaust_wave_memory()
    test_old_daemon_gets_a_clear_message()
    print("pigpio resource test passed")
