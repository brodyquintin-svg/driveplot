"""The desktop launcher starts the controller, shows a window, and stops the controller afterwards."""
import os, stat, subprocess, sys, tempfile, time, urllib.request
ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")


def run(home, browser_body, args, timeout=60):
    fake = os.path.join(home, "fakebrowser.sh")
    with open(fake, "w") as fh:
        fh.write("#!/bin/bash\n" + browser_body)
    os.chmod(fake, os.stat(fake).st_mode | stat.S_IEXEC)
    env = dict(os.environ, HOME=home, PLOTTER_BROWSER=fake, PYTHONPATH=os.path.abspath(ROOT))
    return subprocess.run([sys.executable, "-m", "plotter.app", "--config", os.path.join(home, "c.yaml"), *args],
                          cwd=ROOT, env=env, capture_output=True, text=True, timeout=timeout)


def up(port):
    try:
        urllib.request.urlopen(f"http://127.0.0.1:{port}/api/status", timeout=1)
        return True
    except Exception:
        return False


def test_window_lifecycle():
    home = tempfile.mkdtemp()
    seen = os.path.join(home, "seen")
    # the "browser" fetches the page and the status, then exits (= window closed)
    body = f'''url=$(printf "%s\\n" "$@" | sed -n 's/^--app=//p')
curl -s "$url" | grep -q "<title>Pen plotter" && curl -s "${{url}}api/status" > {seen}\nexit 0\n'''
    r = run(home, body, ["--sim", "--port", "8791"])
    assert r.returncode == 0, r.stderr
    assert '"state"' in open(seen).read()
    time.sleep(0.5)
    assert not up(8791), "controller should stop when the window closes"


def test_reports_start_failure():
    home = tempfile.mkdtemp()
    open(os.path.join(home, "c.yaml"), "w").write("pins:\n  a_step: 5\n  b_step: 5\n")   # duplicate GPIO -> invalid config
    r = run(home, "exit 0\n", ["--sim", "--port", "8792"])
    assert r.returncode == 1 and "didn't start" in r.stderr and "GPIO" in r.stderr


if __name__ == "__main__":
    test_window_lifecycle(); test_reports_start_failure(); print("ok")
