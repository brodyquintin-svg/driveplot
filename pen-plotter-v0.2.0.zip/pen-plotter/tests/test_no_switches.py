import os, sys, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import pytest
from plotter.config import Config, validate, SCHEMA
from plotter.hardware import SimDriver
from plotter.machine import Machine, MachineError


def wait(m):
    while m.busy:
        time.sleep(0.005)
    assert m.state != "error", m.message


def make(**o):
    d = {"screw.r_home_mm": 50, "screw.length_mm": 260, "screw.unusable_mm": 20, "paper.width_mm": 180,
         "paper.height_mm": 180, "pen.settle_s": 0.0, "motors.idle_disable_s": 0}
    d.update(o)
    cfg = Config(d)
    return cfg, Machine(cfg, SimDriver(cfg, speed=0))


def test_default_is_no_switches_and_fields_are_tagged():
    assert Config().v["home.use_switches"] is False
    needs = {f.key for f in SCHEMA if f.needs}
    assert {"pins.theta_switch", "pins.r_switch", "home.fast_hz", "home.max_r_mm"} <= needs
    assert "pins.a_step" not in needs


def test_home_refuses_and_zero_then_jog_works():
    cfg, m = make()
    with pytest.raises(MachineError):
        m.home()
    assert m.status()["use_switches"] is False and m.status()["switches"] == {}
    m.set_zero()
    assert m.homed
    th0, q0, _, _ = m.pose()
    m.move_to_joint(dtheta_deg=5.0); wait(m)
    th1, q1, _, _ = m.pose()
    assert abs((th1 - th0) * 180 / 3.141592653589793 - 5.0) < 0.05
    assert abs(q1 - q0) < 0.05
    # the simulated machine really is where the software thinks it is
    th_true, q_true = m.drv.true_joint()
    assert abs(th_true - th1) < 1e-3 and abs(q_true - q1) < 0.05
    m.shutdown()


def test_zero_survives_unrelated_save_but_not_mechanical_change():
    cfg, m = make()
    m.set_zero()
    cfg.update({"pins.a_step": 4, "paper.width_mm": 200, "motion.draw_speed_mm_s": 30})
    m.reload()
    assert m.homed
    cfg.update({"gears.a_driven_pd_mm": 50})
    m.reload()
    assert not m.homed
    m.shutdown()


def test_switch_pin_clash_ignored_when_switches_off():
    cfg = Config({"pins.theta_switch": 17})            # same GPIO as motor A STEP
    errs, _ = validate(cfg)
    assert not [e for e in errs if "GPIO 17" in e]
    with pytest.raises(Exception):
        Config({"home.use_switches": True, "pins.theta_switch": 17})
