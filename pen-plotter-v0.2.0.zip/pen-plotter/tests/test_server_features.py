"""Line removal, drawing removal, and settings export/import through the HTTP API."""
import os, sys, tempfile
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import yaml
from fastapi.testclient import TestClient
from plotter.server import create_app


def make():
    d = tempfile.mkdtemp()
    app = create_app(os.path.join(d, "config.yaml"), simulate=True, sim_speed=0)
    return TestClient(app)


def test_remove_lines_and_drawing():
    c = make()
    info = c.post("/api/examples/test_shapes.dxf").json()
    n = info["strokes"]
    assert n > 2
    p = c.post("/api/plan", json={}).json()
    assert p["total"] == n and p["indices"] == list(range(n)) and len(p["intended"]) == n
    p2 = c.post("/api/plan", json={"exclude": [0, 2]}).json()
    assert p2["indices"] == [i for i in range(n) if i not in (0, 2)]
    assert len(p2["intended"]) == n - 2 and p2["stats"]["n_strokes"] <= p["stats"]["n_strokes"]
    assert c.post("/api/plan", json={"exclude": list(range(n))}).status_code == 400
    r = c.delete("/api/drawing")
    assert r.status_code == 200 and r.json()["has_drawing"] is False
    assert c.post("/api/plan", json={}).status_code == 400


def test_export_import_roundtrip():
    c = make()
    r = c.post("/api/config/export", json={"gears.a_drive_pd_mm": 17.5, "paper.width_mm": 300})
    assert r.status_code == 200 and "attachment" in r.headers["content-disposition"]
    text = r.text
    assert "# Pen plotter drive settings" in text and "meta" not in yaml.safe_load(text)
    data = yaml.safe_load(text)
    assert data["gears"]["a_drive_pd_mm"] == 17.5 and data["paper"]["width_mm"] == 300
    full = c.get("/api/config").json()["fields"]
    assert set(f["key"] for f in full) == {f"{s}.{k}" for s, b in data.items() for k in b}   # every setting is in the file
    imp = c.post("/api/config/import", json={"text": text}).json()
    assert imp["values"]["gears.a_drive_pd_mm"] == 17.5 and imp["ignored"] == []
    # importing never saves
    cur = {f["key"]: f["value"] for f in c.get("/api/config").json()["fields"]}
    assert cur["gears.a_drive_pd_mm"] != 17.5
    # save what was imported, export again: identical
    c.post("/api/config", json={"values": imp["values"], "confirm": True})
    assert yaml.safe_load(c.post("/api/config/export", json={}).text) == data
    # bad files
    assert c.post("/api/config/import", json={"text": "just words"}).status_code == 400
    assert c.post("/api/config/import", json={"text": "gears: {a_drive_pd_mm: -3}"}).status_code == 400
    j = c.post("/api/config/import", json={"text": '{"paper.height_mm": 250, "nonsense.key": 1}'}).json()
    assert j["values"] == {"paper.height_mm": 250.0} and j["ignored"] == ["nonsense.key"]


if __name__ == "__main__":
    test_remove_lines_and_drawing(); test_export_import_roundtrip(); print("ok")
