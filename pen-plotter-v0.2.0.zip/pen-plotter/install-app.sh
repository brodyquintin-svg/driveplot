#!/usr/bin/env bash
# Adds "Pen Plotter" (and "Pen Plotter (simulator)") to the Pi's application menu and desktop.
#   ./install-app.sh               add the launchers
#   ./install-app.sh --autostart   also open the plotter automatically when the desktop starts
set -euo pipefail
cd "$(dirname "$0")"
ROOT=$PWD

[ -x .venv/bin/python ] || { echo "Run ./install.sh first; it creates the Python environment."; exit 1; }

if ! command -v chromium >/dev/null 2>&1 && ! command -v chromium-browser >/dev/null 2>&1; then
  echo "==> Installing Chromium (used for the app window)"
  sudo apt-get update
  sudo apt-get install -y chromium || sudo apt-get install -y chromium-browser
fi
command -v zenity >/dev/null 2>&1 || sudo apt-get install -y zenity || true   # for readable error pop-ups

apps="$HOME/.local/share/applications"
mkdir -p "$apps"

make_entry() {   # file name comment extra-args
  cat > "$1" <<DESK
[Desktop Entry]
Type=Application
Name=$2
Comment=$3
Exec=$ROOT/.venv/bin/python -m plotter.app$4
Path=$ROOT
Icon=$ROOT/plotter/static/icon.svg
Terminal=false
Categories=Utility;Development;
StartupNotify=true
DESK
  chmod +x "$1"
}

make_entry "$apps/pen-plotter.desktop"     "Pen Plotter"             "Differential swerve pen plotter"        ""
make_entry "$apps/pen-plotter-sim.desktop" "Pen Plotter (simulator)" "Try the plotter without any hardware"  " --sim"
command -v update-desktop-database >/dev/null 2>&1 && update-desktop-database "$apps" 2>/dev/null || true

if [ -d "$HOME/Desktop" ]; then
  for f in pen-plotter pen-plotter-sim; do
    cp "$apps/$f.desktop" "$HOME/Desktop/$f.desktop"
    chmod +x "$HOME/Desktop/$f.desktop"
    gio set "$HOME/Desktop/$f.desktop" metadata::trusted true 2>/dev/null || true
  done
fi

if [ "${1:-}" = "--autostart" ]; then
  mkdir -p "$HOME/.config/autostart"
  cp "$apps/pen-plotter.desktop" "$HOME/.config/autostart/pen-plotter.desktop"
  echo "Autostart on: the plotter opens when the desktop starts."
fi

cat <<MSG

Done. "Pen Plotter" is now in the application menu (Utility) and on the desktop.
  - If the desktop icon asks whether to run it, choose Execute.
  - Use "Pen Plotter (simulator)" to try things with no machine attached.
  - Close the window to quit; the motors are switched off.
MSG
