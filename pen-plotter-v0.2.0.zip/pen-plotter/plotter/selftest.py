"""First-run hardware check for the Raspberry Pi.  Motors are left DISABLED.

    python -m plotter.selftest --config config.yaml

Checks the pigpio daemon, streams a burst of step pulses (nothing moves because
the drivers are disabled) while watching for step-stream underruns, and prints
the state of both home switches so you can press them and confirm wiring.
"""
from __future__ import annotations

import argparse
import threading
import time

import numpy as np

from .config import Config
from .hardware import PigpioDriver, DriverError
from .planner import build_ticks, motion_constant


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="config.yaml")
    ap.add_argument("--rate", type=float, default=None, help="steps/s for the burst (default: config max rate)")
    ap.add_argument("--seconds", type=float, default=5.0)
    a = ap.parse_args(argv)
    cfg = Config.load(a.config)
    try:
        drv = PigpioDriver(cfg)
    except DriverError as e:
        raise SystemExit(f"FAIL: {e}")
    from . import __version__
    print(f"Pen plotter v{__version__} selftest")
    print(f"pigpio connected. Max control blocks per wave: {drv.max_cbs}; events per wave: {drv.max_events}")
    drv.enable(False)
    rate = a.rate or cfg["motion.max_step_rate_hz"]
    n = int(rate * a.seconds)
    print(f"Streaming {n} steps per motor at {rate:.0f} steps/s for {a.seconds:.0f} s (drivers disabled)...")
    tk = build_ticks(motion_constant(n, n, rate), (1, 1))
    t0 = time.monotonic()
    drv.run(tk, threading.Event())
    dt = time.monotonic() - t0
    print(f"  took {dt:.2f} s (ideal {a.seconds:.2f} s), underruns: {drv.underruns}")
    if drv.underruns or dt > a.seconds * 1.05:
        print("  WARNING: the Pi couldn't keep the pulse stream fed. Lower motion.max_step_rate_hz, close other programs,")
        print("           and make sure pigpiod runs with default settings (sudo systemctl restart pigpiod).")
    else:
        print("  OK: pulse streaming keeps up.")
    if not cfg["home.use_switches"]:
        print("\nNo limit switches configured, so there is nothing more to check. Next: wire the drivers, then use")
        print("the app's Move tab > Motor test to spin each motor.")
        drv.close()
        return
    print("\nHome switches (press each one; Ctrl+C to quit):")
    try:
        while True:
            print(f"\r  swing switch: {'PRESSED ' if drv.read_switch('theta') else 'open    '}   reach switch: {'PRESSED ' if drv.read_switch('r') else 'open    '}", end="", flush=True)
            time.sleep(0.15)
    except KeyboardInterrupt:
        print()
    finally:
        drv.close()


if __name__ == "__main__":
    main()
