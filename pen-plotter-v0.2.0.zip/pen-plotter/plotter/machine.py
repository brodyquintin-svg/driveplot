"""Machine controller: state, homing, jogging and job execution."""
from __future__ import annotations

import math
import threading
import time
from collections import deque

import numpy as np

from .config import Config
from .hardware import BaseDriver, DriverError
from .kinematics import Kinematics
from .planner import (Plan, build_ticks, motion_constant, motion_from_draw, travel_motion, Ticks)


class MachineError(RuntimeError):
    pass


_GEOM_KEYS = ("gears.", "bevel.", "screw.", "motors.", "home.theta", "home.r_dir", "home.backoff", "limits.")


def _geom_key(v):
    """Settings that change what a motor step means. Saving anything else keeps the zero position."""
    return tuple((k, v[k]) for k in sorted(v) if k.startswith(_GEOM_KEYS) and k != "home.use_switches")


class Machine:
    def __init__(self, cfg: Config, driver: BaseDriver):
        self.cfg = cfg
        self.drv = driver
        self.kin = Kinematics(cfg)
        self.raw = [0, 0]              # logical steps since power-up
        self.off = [0, 0]              # raw - off = steps from home pose
        self.homed = False
        self._gkey = _geom_key(cfg.v)
        self.last_dir = [0, 0]
        self.pen_down = False
        self.state = "idle"            # idle | homing | moving | running | paused | error
        self.message = ""
        self.job: dict | None = None
        self.trace: list = []          # [x, y, pen] samples of where the pen has been
        self.logs: deque = deque(maxlen=300)
        self._halt = threading.Event()
        self._resume = threading.Event()
        self._pause_req = False
        self._stop_req = False
        self._task: threading.Thread | None = None
        self._lock = threading.RLock()
        self._last_activity = time.monotonic()
        self._motors_on = False
        self._alive = True
        threading.Thread(target=self._watchdog, daemon=True).start()

    # ------------------------------------------------------------------ util
    def log(self, msg: str):
        self.logs.append(f"{time.strftime('%H:%M:%S')}  {msg}")

    @property
    def pos(self):
        return (self.raw[0] - self.off[0], self.raw[1] - self.off[1])

    def pose(self):
        th, q = self.kin.steps_to_joint(*self.pos)
        x, y = self.kin.joint_to_xy(th, q)
        return float(th), float(q), float(x), float(y)

    def _sleep(self, s):
        if self.drv.sim and getattr(self.drv, "speed", 0) > 0:
            s = s / self.drv.speed
        t_end = time.monotonic() + s
        while time.monotonic() < t_end:
            if self._halt.is_set():
                return
            time.sleep(min(0.02, max(0, t_end - time.monotonic())))

    def _motors(self, on: bool):
        self.drv.enable(on)
        self._motors_on = on

    def _watchdog(self):
        while self._alive:
            time.sleep(2.0)
            lim = self.cfg["motors.idle_disable_s"]
            if lim > 0 and self._motors_on and self.state == "idle" and time.monotonic() - self._last_activity > lim:
                try:
                    self._motors(False)
                    self.log("Motors disabled after idle timeout (position still valid unless moved by hand)")
                except Exception:
                    pass

    def reload(self, driver: BaseDriver | None = None):
        """Call after settings change."""
        if self.busy:
            raise MachineError("Machine is busy")
        if driver is not None:
            try:
                self.drv.close()
            except Exception:
                pass
            self.drv = driver
        self.kin = Kinematics(self.cfg)
        key = _geom_key(self.cfg.v)
        if self.homed and key != getattr(self, "_gkey", key):
            self.log("Mechanical settings changed: set the zero position again before running a job")
            self.homed = False
            self.off = list(self.raw)
        self._gkey = key

    @property
    def use_switches(self):
        return bool(self.cfg.v["home.use_switches"])

    @property
    def busy(self):
        return self._task is not None and self._task.is_alive()

    def _start(self, name, fn):
        with self._lock:
            if self.busy:
                raise MachineError("Machine is busy")
            self._halt.clear()
            self._resume.clear()
            self._pause_req = self._stop_req = False
            self.message = ""

            def wrapper():
                try:
                    fn()
                    if self.state not in ("error",):
                        self.state = "idle"
                except _Halt:
                    self.state = "idle"
                    self.log(f"{name}: stopped")
                except Exception as e:  # noqa
                    self.state = "error"
                    self.message = str(e)
                    self.log(f"{name} FAILED: {e}")
                finally:
                    self._last_activity = time.monotonic()
                    self.job_done = True
            self.job_done = False
            self._task = threading.Thread(target=wrapper, daemon=True, name=name)
            self._task.start()

    # ------------------------------------------------------------- low-level
    def _play(self, tk: Ticks, draw=False):
        """Play a tick stream. Handles pause/stop at chunk boundaries. Returns True if completed."""
        if len(tk) == 0:
            return True
        ca, cb = tk.cumulative()
        base = tuple(self.raw)
        start = 0
        last_xy = [None]
        n_chunk = [0]

        def on_chunk(i):
            self.raw[0] = base[0] + int(ca[i - 1])
            self.raw[1] = base[1] + int(cb[i - 1])
            n_chunk[0] += 1
            if self.homed:
                th, q, x, y = self.pose()
                lx = last_xy[0]
                if lx is None or (x - lx[0]) ** 2 + (y - lx[1]) ** 2 > 0.25 ** 2:
                    self.trace.append([round(x, 2), round(y, 2), 1 if self.pen_down else 0])
                    last_xy[0] = (x, y)
                    if len(self.trace) > 250_000:
                        del self.trace[:50_000]
                if n_chunk[0] % 5 == 0 and not self.drv.sim:
                    self._check_unexpected_switch()
            if self.job is not None:
                self.job["frac_in_op"] = i / len(tk)
            return not self._halt.is_set()

        while True:
            reached = self.drv.run(tk, self._halt, start, on_chunk)
            if reached > 0:
                self.raw[0] = base[0] + int(ca[reached - 1])
                self.raw[1] = base[1] + int(cb[reached - 1])
                self._update_last_dir(tk, reached)
            if reached >= len(tk):
                self.raw[0] = base[0] + tk.net[0]
                self.raw[1] = base[1] + tk.net[1]
                return True
            if self._stop_req:
                return False
            if self._pause_req:
                self._do_pause(draw)
                if self._stop_req:
                    return False
                start = reached
                continue
            return False

    def _update_last_dir(self, tk: Ticks, reached):
        m = tk.mask[:reached]
        if (m & 1).any():
            self.last_dir[0] = int(tk.dir_a[reached - 1])
        if (m & 2).any():
            self.last_dir[1] = int(tk.dir_b[reached - 1])

    def _do_pause(self, draw):
        self.state = "paused"
        was_down = self.pen_down
        self._halt.clear()
        if was_down:
            self._set_pen(False)
        self.log("Paused")
        self._resume.clear()
        while not self._resume.wait(0.1):
            if self._stop_req:
                return
        if self._stop_req:
            return
        if was_down:
            self._set_pen(True)
        self._pause_req = False
        self._halt.clear()
        self.state = "running"
        self.log("Resumed")

    def _check_unexpected_switch(self):
        """If a home switch is pressed while we think we're far from it, steps were lost."""
        c = self.cfg.v
        if not self.use_switches:
            return
        th, q, _, _ = self.pose()
        if self.drv.read_switch("theta"):
            clear = -(th - self.kin.theta_home) * c["home.theta_dir"]
            if clear > math.radians(c["home.backoff_deg"]) * 1.5 + 1e-3:
                self._lost("theta")
        if self.drv.read_switch("r"):
            q_home = 0.0 if c["home.r_dir"] < 0 else self.kin.travel
            clear = -(q - q_home) * c["home.r_dir"]
            if clear > c["home.backoff_mm"] * 1.5 + 0.2:
                self._lost("r")

    def _lost(self, which):
        self.drv.abort_hard()
        self.homed = False
        self._motors_on = False
        raise MachineError(f"{which} home switch hit unexpectedly: steps were lost. Motors disabled, re-home required.")

    def _move_steps(self, tk: Ticks, draw=False):
        ok = self._play(tk, draw)
        if not ok:
            raise _Halt()

    def _set_pen(self, down: bool):
        self.drv.set_pen(down)
        self.pen_down = down
        self._sleep(self.cfg["pen.settle_s"])

    def _ticks(self, motion):
        c = self.cfg.v
        return build_ticks(motion, tuple(self.last_dir),
                           (c["motion.backlash_a_steps"], c["motion.backlash_b_steps"]), c["motion.backlash_rate_hz"])

    def _travel_to(self, target):
        tm = travel_motion(self.kin, self.cfg, self.pos[0], self.pos[1], target[0], target[1])
        self._move_steps(self._ticks(tm))

    # ---------------------------------------------------------- joint helpers
    def _joint_steps(self, kind, sigma, amount):
        """Motor step deltas for a joint change. kind: 'theta' (rad) or 'r' (mm)."""
        k = self.kin
        if kind == "theta":
            dphi = k.ts * sigma * amount
            return int(round(dphi * k.sA)), int(round(dphi * k.sB))
        S = amount / k.lead * 2 * math.pi
        d = k.rs * sigma * S / k.k
        return int(round(d * k.sA)), int(round(-d * k.sB))

    def _homing_seek(self, kind, sigma, rate, max_amount, fine=False):
        """Move in direction sigma until the switch reads pressed. Returns raw counts at the trigger."""
        name = "theta" if kind == "theta" else "r"
        # chunk ~ 15 ms of travel (or one step for the fine approach)
        a, b = self._joint_steps(kind, 1, 1.0)
        dom_per_unit = max(abs(a), abs(b), 1e-9)
        chunk_steps = 1 if fine else max(2, int(rate * 0.015))
        amount = chunk_steps / dom_per_unit
        travelled = 0.0
        while not self.drv.read_switch(name):
            if self._halt.is_set():
                raise _Halt()
            dA, dB = self._joint_steps(kind, sigma, amount)
            self._move_steps(self._ticks(motion_constant(dA, dB, rate)))
            travelled += amount
            if travelled > max_amount:
                raise MachineError(f"Home switch '{name}' not found within {max_amount:.0f} {'rad' if kind == 'theta' else 'mm'}. "
                                   f"Check wiring, 'Direction toward switch', and switch pin.")
        return tuple(self.raw)

    def _backoff(self, kind, sigma, amount, rate):
        name = "theta" if kind == "theta" else "r"
        dA, dB = self._joint_steps(kind, sigma, amount)
        self._move_steps(self._ticks(motion_constant(dA, dB, rate)))
        guard = 0
        while self.drv.read_switch(name) and guard < 200:
            dA, dB = self._joint_steps(kind, sigma, amount * 0.25)
            self._move_steps(self._ticks(motion_constant(dA, dB, rate)))
            guard += 1

    def _home_axis(self, kind):
        c = self.cfg.v
        toward = c["home.theta_dir"] if kind == "theta" else c["home.r_dir"]
        fast, slow = c["home.fast_hz"], c["home.slow_hz"]
        if kind == "theta":
            back, mx = math.radians(c["home.backoff_deg"]), math.radians(c["home.max_theta_deg"])
        else:
            back, mx = c["home.backoff_mm"], c["home.max_r_mm"]
        name = "theta" if kind == "theta" else "r"
        if self.drv.read_switch(name):                      # already pressed: clear it first
            self._backoff(kind, -toward, back * 2, slow * 2)
        self._homing_seek(kind, toward, fast, mx)
        self._backoff(kind, -toward, back, fast)
        trig = self._homing_seek(kind, toward, slow, back * 4, fine=True)
        self._backoff(kind, -toward, back, slow * 2)
        return trig

    # ------------------------------------------------------------------ tasks
    def home(self):
        if not self.use_switches:
            raise MachineError("No limit switches are set up. Move the arm to its zero position by hand and press 'Set zero here'.")

        def task():
            self.state = "homing"
            self.homed = False
            self.log("Homing...")
            self._motors(True)
            self._set_pen(False)
            self.last_dir = [0, 0]
            k, c = self.kin, self.cfg.v
            ra, rb = self._home_axis("r")
            ta, tb = self._home_axis("theta")
            q_home = 0.0 if c["home.r_dir"] < 0 else k.travel
            S_home = q_home / k.lead * 2 * math.pi
            D = 2 * k.rs * S_home / k.k                      # phiA - phiB at r trigger
            u = ra / k.sA - rb / k.sB - D
            w = ta / k.sA + tb / k.sB
            self.off = [int(round(k.sA * (u + w) / 2)), int(round(k.sB * (w - u) / 2))]
            self.homed = True
            self._gkey = _geom_key(c)
            th, q, x, y = self.pose()
            self.log(f"Homed. Arm {math.degrees(th):.1f} deg, extension {q:.1f} mm, pen at ({x:.1f}, {y:.1f})")
            self.trace.clear()
        self._start("home", task)

    def set_zero(self):
        """Declare the current physical pose to be the home pose (no switches needed)."""
        if self.busy:
            raise MachineError("Machine is busy")
        c = self.cfg.v
        th = math.radians(c["home.theta_deg"]) - c["home.theta_dir"] * math.radians(c["home.backoff_deg"])
        q = -c["home.r_dir"] * c["home.backoff_mm"] if c["home.r_dir"] < 0 else self.kin.travel - c["home.backoff_mm"]
        a, b = self.kin.joint_to_steps(th, q)
        self.off = [self.raw[0] - int(round(float(a))), self.raw[1] - int(round(float(b)))]
        self.homed = True
        self._gkey = _geom_key(c)
        self.trace.clear()
        self.log("Zero position set")

    def move_to_joint(self, theta_deg=None, dtheta_deg=0.0, dq_mm=0.0, q_mm=None, lift=True):
        def task():
            if not self.homed:
                raise MachineError("Home the machine first")
            self.state = "moving"
            self._motors(True)
            th, q, _, _ = self.pose()
            nth = math.radians(theta_deg) if theta_deg is not None else th + math.radians(dtheta_deg)
            nq = q_mm if q_mm is not None else q + dq_mm
            self._check_joint(nth, nq)
            a, b = self.kin.joint_to_steps(nth, nq)
            if lift and self.pen_down:
                self._set_pen(False)
            self._travel_to((int(round(float(a))), int(round(float(b)))))
        self._start("jog", task)

    def _check_joint(self, th, q):
        k = self.kin
        if not (k.theta_min - 1e-9 <= th <= k.theta_max + 1e-9):
            raise MachineError(f"Angle {math.degrees(th):.1f} deg is outside the soft limits "
                               f"({math.degrees(k.theta_min):.0f}..{math.degrees(k.theta_max):.0f})")
        if not (-1e-9 <= q <= k.travel + 1e-9):
            raise MachineError(f"Extension {q:.1f} mm is outside 0..{k.travel:.1f} mm")

    def goto_xy(self, x, y):
        def task():
            if not self.homed:
                raise MachineError("Home the machine first")
            if not self.kin.reachable(np.array([x]), np.array([y]))[0]:
                raise MachineError(f"({x:.1f}, {y:.1f}) is outside the pen's reach")
            self.state = "moving"
            self._motors(True)
            a, b = self.kin.xy_to_steps(np.array([x]), np.array([y]))
            if self.pen_down:
                self._set_pen(False)
            self._travel_to((int(round(float(a[0]))), int(round(float(b[0])))))
        self._start("goto", task)

    def pen(self, down: bool):
        def task():
            self.state = "moving"
            self._set_pen(down)
        self._start("pen", task)

    def nudge_motor(self, motor: str, steps: int):
        """Bring-up tool: move one motor by raw logical steps (works before homing)."""
        def task():
            self.state = "moving"
            self._motors(True)
            dA, dB = (steps, 0) if motor == "a" else (0, steps)
            self._move_steps(self._ticks(motion_constant(dA, dB, 400.0)))
            if self.homed:
                self.log("Motor nudged: position tracked, but check that re-homing isn't needed")
        self._start("nudge", task)

    def park(self):
        def task():
            if not self.homed:
                raise MachineError("Home the machine first")
            self.state = "moving"
            if self.pen_down:
                self._set_pen(False)
            self._travel_to(self.park_steps())
        self._start("park", task)

    def park_steps(self):
        c = self.cfg.v
        th = math.radians(c["home.theta_deg"]) - c["home.theta_dir"] * math.radians(c["home.backoff_deg"])
        q = c["home.backoff_mm"] if c["home.r_dir"] < 0 else self.kin.travel - c["home.backoff_mm"]
        a, b = self.kin.joint_to_steps(th, q)
        return (int(round(float(a))), int(round(float(b))))

    def motors(self, on: bool):
        if self.busy:
            raise MachineError("Machine is busy")
        self._motors(on)
        self._last_activity = time.monotonic()

    def run_job(self, plan: Plan):
        if not plan.ops:
            raise MachineError("Nothing to draw")
        if not self.homed:
            raise MachineError("Home the machine first")
        if not self.cfg.confirmed and not self.drv.sim:
            raise MachineError("Settings haven't been confirmed. Review them and press Save first.")

        def task():
            self.state = "running"
            self._motors(True)
            total = max(sum(plan.op_times), 1e-6)
            done = 0.0
            self.job = dict(n_ops=len(plan.ops), op=0, frac_in_op=0.0, est_total=total, t0=time.monotonic(), time_done=0.0, finished=False)
            self.trace.clear()
            self.log(f"Job started: {plan.stats['n_strokes']} strokes, est. {total / 60:.1f} min")
            try:
                for i, op in enumerate(plan.ops):
                    self.job.update(op=i, frac_in_op=0.0, time_done=done)
                    if self._stop_req:
                        raise _Halt()
                    kind = op[0]
                    if kind == "pen":
                        self._set_pen(op[1])
                    elif kind == "travel":
                        self._travel_to(op[1])
                    elif kind == "draw":
                        dp = op[1]
                        if abs(self.pos[0] - dp.start[0]) > 2 or abs(self.pos[1] - dp.start[1]) > 2:
                            raise MachineError("Position mismatch at stroke start (steps were lost?). Re-home and retry.")
                        tk = self._ticks(motion_from_draw(dp))
                        self._move_steps(tk, draw=True)
                    done += plan.op_times[i]
                self.job.update(op=len(plan.ops), frac_in_op=0.0, time_done=total)
                self.log("Job finished")
            finally:
                if self.pen_down:
                    try:
                        self._halt.clear()
                        self._set_pen(False)
                    except Exception:
                        pass
                self.job["finished"] = True
        self._start("job", task)

    # -------------------------------------------------------------- control
    def pause(self):
        if self.state == "running":
            self._pause_req = True
            self._halt.set()

    def resume(self):
        if self.state == "paused":
            self._resume.set()

    def stop(self):
        """Graceful stop: finish the current chunk, lift the pen. Position remains valid."""
        self._stop_req = True
        self._halt.set()
        self._resume.set()

    def estop(self):
        """Immediate stop. Position is no longer trusted."""
        self._stop_req = True
        self._halt.set()
        self._resume.set()
        self.drv.abort_hard()
        self._motors_on = False
        self.homed = False
        self.state = "error"
        self.message = "Emergency stop. Re-home before continuing."
        self.log("EMERGENCY STOP")

    def clear_error(self):
        if not self.busy and self.state == "error":
            self.state = "idle"
            self.message = ""

    # --------------------------------------------------------------- status
    def status(self):
        th, q, x, y = self.pose()
        j = None
        if self.job is not None:
            jj = self.job
            total = jj["est_total"]
            frac = min(1.0, jj["time_done"] / total)
            j = dict(progress=frac, elapsed=time.monotonic() - jj["t0"], est_total=total,
                     finished=jj["finished"], op=jj["op"], n_ops=jj["n_ops"])
        sw = {}
        try:
            if self.use_switches:
                sw = dict(theta=self.drv.read_switch("theta"), r=self.drv.read_switch("r"))
        except Exception:
            pass
        return dict(state=self.state, message=self.message, homed=self.homed, pen_down=self.pen_down,
                    x=x, y=y, theta_deg=math.degrees(th), q_mm=q,
                    steps=list(self.pos), switches=sw, job=j, sim=self.drv.sim, driver=self.drv.name,
                    motors_on=self._motors_on, underruns=getattr(self.drv, "underruns", 0),
                    confirmed=self.cfg.confirmed, n_trace=len(self.trace), use_switches=self.use_switches)

    def shutdown(self):
        self._alive = False
        self._stop_req = True
        self._halt.set()
        self._resume.set()
        try:
            self.drv.close()
        except Exception:
            pass


class _Halt(Exception):
    pass
