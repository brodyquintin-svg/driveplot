"""Place a drawing on the paper and into the pivot-centred workspace frame."""
from __future__ import annotations

import math
from dataclasses import dataclass, asdict, field

import numpy as np

from .config import Config


@dataclass
class LayoutOptions:
    fit: str = "reach"          # reach | fit | actual | scale
    scale: float = 1.0          # used when fit == 'scale'
    rotate_deg: int = 0         # 0, 90, 180, 270 (CCW)
    mirror_x: bool = False
    margin_mm: float = 10.0
    align: str = "center"       # center | bl
    offset_x_mm: float = 0.0
    offset_y_mm: float = 0.0
    exclude: list = field(default_factory=list)   # indices of strokes removed from the job

    @classmethod
    def from_dict(cls, d: dict | None):
        d = d or {}
        o = cls()
        for k, v in d.items():
            if hasattr(o, k):
                if k == "exclude":
                    o.exclude = sorted({int(i) for i in (v or [])})
                else:
                    setattr(o, k, type(getattr(o, k))(v) if not isinstance(getattr(o, k), bool) else bool(v))
        return o

    def to_dict(self):
        return asdict(self)


def _hull(P: np.ndarray) -> np.ndarray:
    pts = sorted(map(tuple, np.unique(np.round(P, 3), axis=0).tolist()))
    if len(pts) < 3:
        return np.array(pts)
    def cross(o, a, b):
        return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])
    lo, up = [], []
    for p in pts:
        while len(lo) >= 2 and cross(lo[-2], lo[-1], p) <= 0:
            lo.pop()
        lo.append(p)
    for p in reversed(pts):
        while len(up) >= 2 and cross(up[-2], up[-1], p) <= 0:
            up.pop()
        up.append(p)
    return np.array(lo[:-1] + up[:-1])


def _fit_reach(st, opts, cfg, kin):
    """Largest scale and a position where every sample point is reachable and on the paper."""
    W, H = cfg["paper.width_mm"], cfg["paper.height_mm"]
    ox, oy = cfg["paper.origin_x_mm"], cfg["paper.origin_y_mm"]
    m = opts.margin_mm
    allp = np.vstack(st)
    mn = allp.min(axis=0)
    loc = allp - mn
    w, h = max(loc[:, 0].max(), 1e-9), max(loc[:, 1].max(), 1e-9)
    coarse = loc[:: max(1, len(loc) // 4000)]
    hull = _hull(coarse)
    uni = loc[np.linspace(0, len(loc) - 1, min(len(loc), 220)).astype(int)]
    S = np.vstack([hull, uni, [[0, 0], [w, 0], [0, h], [w, h]]])
    aw, ah = W - 2 * m, H - 2 * m
    if aw <= 0 or ah <= 0:
        return None
    s_hi = min(aw / w, ah / h)

    def best_pos(scale, step, around=None, span=0.0):
        xs_hi, ys_hi = W - m - w * scale, H - m - h * scale
        if xs_hi < m - 1e-9 or ys_hi < m - 1e-9:
            return None
        if around is None:
            xs = np.append(np.arange(m, xs_hi, step), xs_hi)
            ys = np.append(np.arange(m, ys_hi, step), ys_hi)
        else:
            xs = np.clip(np.arange(around[0] - span, around[0] + span + 1e-9, step), m, xs_hi)
            ys = np.clip(np.arange(around[1] - span, around[1] + span + 1e-9, step), m, ys_hi)
        G = np.stack(np.meshgrid(xs, ys), -1).reshape(-1, 2)
        pts = (S * scale)[None, :, :] + G[:, None, :] + np.array([ox, oy])
        ok = kin.reachable(pts[..., 0].ravel(), pts[..., 1].ravel()).reshape(len(G), len(S)).all(axis=1)
        if not ok.any():
            return None
        cand = G[ok]
        ctr = np.array([m + (aw - w * scale) / 2, m + (ah - h * scale) / 2])
        return tuple(cand[np.argmin(((cand - ctr) ** 2).sum(1))])

    found = None
    fail_scale = None
    for scale in np.geomspace(s_hi, s_hi * 0.04, 70):
        pos = best_pos(scale, 8.0)
        if pos is not None:
            found = (scale, pos)
            break
        fail_scale = scale
    if found is None:
        return None
    scale, pos = found
    if fail_scale is not None:                    # refine between the last failure and the first success
        lo, hi = scale, fail_scale
        for _ in range(9):
            mid = (lo + hi) / 2
            p2 = best_pos(mid, 1.0, around=pos, span=10.0) or best_pos(mid, 8.0)
            if p2 is not None:
                lo, pos = mid, p2
            else:
                hi = mid
        scale = lo
        pos = best_pos(scale, 1.0, around=pos, span=10.0) or pos
    return scale * 0.998, pos                      # tiny safety margin


def apply_layout(strokes, opts: LayoutOptions, cfg: Config, kin=None):
    """Returns (strokes in workspace frame, info dict)."""
    W, H = cfg["paper.width_mm"], cfg["paper.height_mm"]
    ox, oy = cfg["paper.origin_x_mm"], cfg["paper.origin_y_mm"]
    th = math.radians(opts.rotate_deg)
    c, s = math.cos(th), math.sin(th)
    R = np.array([[c, -s], [s, c]])
    st = []
    for a in strokes:
        b = a.copy()
        if opts.mirror_x:
            b[:, 0] *= -1
        st.append(b @ R.T)
    allp = np.vstack(st)
    mn, mx = allp.min(axis=0), allp.max(axis=0)
    w, h = max(mx[0] - mn[0], 1e-9), max(mx[1] - mn[1], 1e-9)
    aw, ah = W - 2 * opts.margin_mm, H - 2 * opts.margin_mm
    note = None
    reach_pos = None
    if opts.fit == "reach" and kin is not None:
        r = _fit_reach(st, opts, cfg, kin)
        if r is None:
            note = "Couldn't find a placement where the whole drawing is within reach; falling back to fit-to-paper."
            scale = min(aw / w, ah / h) if aw > 0 and ah > 0 else 1.0
        else:
            scale, reach_pos = r
    elif opts.fit in ("fit", "reach"):
        scale = min(aw / w, ah / h) if aw > 0 and ah > 0 else 1.0
    elif opts.fit == "scale":
        scale = opts.scale
    else:
        scale = 1.0
    w2, h2 = w * scale, h * scale
    if reach_pos is not None:
        px, py = reach_pos
    elif opts.align == "center":
        px = opts.margin_mm + (aw - w2) / 2
        py = opts.margin_mm + (ah - h2) / 2
    else:
        px, py = opts.margin_mm, opts.margin_mm
    px += opts.offset_x_mm
    py += opts.offset_y_mm
    out = [((a - mn) * scale + np.array([px, py])) + np.array([ox, oy]) for a in st]
    info = dict(note=note, scale=scale, width_mm=w2, height_mm=h2, fits_paper=bool(px >= -1e-6 and py >= -1e-6 and px + w2 <= W + 1e-6 and py + h2 <= H + 1e-6))
    return out, info
