"""Hardware drivers: PigpioDriver (real Pi 4) and SimDriver (no hardware).

Both consume the same `Ticks` stream produced by the planner.
"""
from __future__ import annotations

import threading
import time

import numpy as np

from .config import Config
from .kinematics import Kinematics
from .planner import Ticks, TICK_US

PULSE_US = 4            # STEP high time (A4988/DRV8825/TMC2209 all need >= 2 us)
MAX_EVENTS_PER_WAVE = 400
MAX_US_PER_WAVE = 50_000


def chunk_bounds(t_us: np.ndarray, start: int, max_events: int, max_us: int):
    """Yield (i0, i1) slices of at most max_events / max_us each."""
    n = len(t_us)
    i = start
    while i < n:
        j = int(np.searchsorted(t_us, t_us[i] + max_us, side="right"))
        j = min(max(j, i + 1), i + max_events, n)
        yield i, j
        i = j


class DriverError(RuntimeError):
    pass


class BaseDriver:
    name = "base"
    sim = False

    def __init__(self, cfg: Config):
        self.cfg = cfg
        self.underruns = 0

    def enable(self, on: bool): ...
    def set_pen(self, down: bool): ...
    def read_switch(self, name: str) -> bool: ...
    def run(self, ticks: Ticks, stop: threading.Event, start: int = 0, on_chunk=None) -> int:
        """Play ticks[start:]. Returns the index reached (len(ticks) if finished)."""
        raise NotImplementedError
    def abort_hard(self): ...
    def close(self): ...


# ===========================================================================
class PigpioDriver(BaseDriver):
    name = "pigpio"

    def __init__(self, cfg: Config, host=None):
        super().__init__(cfg)
        try:
            import pigpio
        except ImportError as e:
            raise DriverError("python3-pigpio is not installed (sudo apt install python3-pigpio pigpio)") from e
        self.pigpio = pigpio
        self.pi = pigpio.pi(host) if host else pigpio.pi()
        if not self.pi.connected:
            raise DriverError("Cannot reach the pigpio daemon. Run: sudo systemctl enable --now pigpiod")
        c = cfg.v
        self.pin = {k.split(".")[1]: v for k, v in c.items() if k.startswith("pins.") and k != "pins.switch_active_low"}
        pi = self.pi
        for k in ("a_step", "a_dir", "a_en", "b_step", "b_dir", "b_en"):
            pi.set_mode(self.pin[k], pigpio.OUTPUT)
            pi.write(self.pin[k], 0)
        self.use_switches = bool(c["home.use_switches"])
        for k in (("theta_switch", "r_switch") if self.use_switches else ()):
            pi.set_mode(self.pin[k], pigpio.INPUT)
            pi.set_pull_up_down(self.pin[k], pigpio.PUD_UP if c["pins.switch_active_low"] else pigpio.PUD_DOWN)
            pi.set_glitch_filter(self.pin[k], 500)
        self.enable(False)
        self.stepA, self.stepB = 1 << self.pin["a_step"], 1 << self.pin["b_step"]
        self.dirA, self.dirB = 1 << self.pin["a_dir"], 1 << self.pin["b_dir"]
        self.step_all = self.stepA | self.stepB
        self.dir_all = self.dirA | self.dirB
        self.invA, self.invB = c["motors.a_invert"], c["motors.b_invert"]
        self.max_cbs = pi.wave_get_max_cbs()
        self.max_events = max(40, min(MAX_EVENTS_PER_WAVE, self.max_cbs // 16))
        pi.wave_clear()
        self._servo_us = None

    # -- simple IO ---------------------------------------------------------
    def enable(self, on: bool):
        lvl = 0 if self.cfg["motors.enable_active_low"] else 1
        lvl = lvl if on else 1 - lvl
        self.pi.write(self.pin["a_en"], lvl)
        self.pi.write(self.pin["b_en"], lvl)

    def set_pen(self, down: bool):
        us = self.cfg["pen.down_us"] if down else self.cfg["pen.up_us"]
        self.pi.set_servo_pulsewidth(self.pin["servo"], us)

    def read_switch(self, name: str) -> bool:
        if not self.use_switches:
            return False
        lvl = self.pi.read(self.pin[name + "_switch"])
        return (lvl == 0) if self.cfg["pins.switch_active_low"] else (lvl == 1)

    # -- wave streaming ----------------------------------------------------
    def _pulses(self, tk: Ticks, i0: int, i1: int):
        P = self.pigpio.pulse
        t = tk.t_us[max(i0 - 1, 0):i1]
        prev = int(tk.t_us[i0 - 1]) if i0 > 0 else 0
        gaps = np.diff(np.concatenate([[prev], tk.t_us[i0:i1]])).astype(np.int64)
        ha = (tk.dir_a[i0:i1] > 0) ^ self.invA
        hb = (tk.dir_b[i0:i1] > 0) ^ self.invB
        d_on = np.where(ha, self.dirA, 0) | np.where(hb, self.dirB, 0)
        d_off = self.dir_all & ~d_on
        m = tk.mask[i0:i1]
        s_on = np.where(m & 1, self.stepA, 0) | np.where(m & 2, self.stepB, 0)
        low = (gaps - PULSE_US).tolist()
        d_on, d_off, s_on = d_on.tolist(), (d_off | self.step_all).tolist(), s_on.tolist()
        out = []
        ap = out.append
        for k in range(len(low)):
            ap(P(d_on[k], d_off[k], low[k]))
            ap(P(s_on[k], 0, PULSE_US))
        return out

    def run(self, ticks, stop, start=0, on_chunk=None):
        pi, pg = self.pi, self.pigpio
        if len(ticks) == 0 or start >= len(ticks):
            return len(ticks)
        prev_wid = None
        reached = start
        try:
            for i0, i1 in chunk_bounds(ticks.t_us, start, self.max_events, MAX_US_PER_WAVE):
                if stop.is_set():
                    break
                pi.wave_add_generic(self._pulses(ticks, i0, i1))
                wid = pi.wave_create()
                if wid < 0:
                    raise DriverError(f"pigpio wave_create failed ({wid}); lower motion.max_step_rate_hz")
                if prev_wid is None:
                    pi.wave_send_using_mode(wid, pg.WAVE_MODE_ONE_SHOT)
                else:
                    if pi.wave_tx_at() == 9999:
                        self.underruns += 1
                    pi.wave_send_using_mode(wid, pg.WAVE_MODE_ONE_SHOT_SYNC)
                    # wait until the new wave has taken over, then free the old one
                    deadline = time.monotonic() + 2.0
                    while pi.wave_tx_at() == prev_wid and time.monotonic() < deadline:
                        time.sleep(0.0005)
                    pi.wave_delete(prev_wid)
                prev_wid = wid
                reached = i1
                if on_chunk and on_chunk(i1) is False:
                    break
        finally:
            while pi.wave_tx_busy():
                time.sleep(0.001)
            if prev_wid is not None:
                pi.wave_delete(prev_wid)
            pi.wave_add_generic([pg.pulse(0, self.step_all, 2)])   # STEP low at rest
            w = pi.wave_create()
            if w >= 0:
                pi.wave_send_once(w)
                while pi.wave_tx_busy():
                    time.sleep(0.0005)
                pi.wave_delete(w)
        return reached

    def abort_hard(self):
        try:
            self.pi.wave_tx_stop()
            self.pi.wave_clear()
        except Exception:
            pass
        self.enable(False)

    def close(self):
        try:
            self.abort_hard()
            self.pi.set_servo_pulsewidth(self.pin["servo"], 0)
            self.pi.stop()
        except Exception:
            pass


# ===========================================================================
class SimDriver(BaseDriver):
    """Virtual machine. Integrates the same tick stream the real driver plays.

    The machine starts at an arbitrary hidden pose so homing can be exercised.
    """
    name = "simulator"
    sim = True

    def __init__(self, cfg: Config, speed: float = 20.0, start_pose=None, lash=(0.0, 0.0)):
        super().__init__(cfg)
        self.lash = lash                         # simulated mechanical backlash (steps) per motor
        self.kin = Kinematics(cfg)
        self.speed = speed                       # 0 = as fast as possible
        c = cfg.v
        if start_pose is None and not c["home.use_switches"]:      # no switches: starts at the zero position
            start_pose = (np.radians(c["home.theta_deg"]) - c["home.theta_dir"] * np.radians(c["home.backoff_deg"]),
                          c["home.backoff_mm"] if c["home.r_dir"] < 0 else self.kin.travel - c["home.backoff_mm"])
        th0, q0 = start_pose if start_pose is not None else (self.kin.theta_home + np.radians(23.0), 37.0)
        a0, b0 = self.kin.joint_to_steps(th0, q0)
        self.abs_a, self.abs_b = float(np.rint(a0)), float(np.rint(b0))   # gear position, steps from true home
        self.mot_a, self.mot_b = self.abs_a, self.abs_b                  # motor shaft position
        self.enabled = False
        self.pen_down = False
        self.trace: list = []          # (x, y) polylines actually inked
        self._cur: list | None = None
        self.phys_steps = 0

    # ---- helpers ---------------------------------------------------------
    def true_joint(self):
        th, q = self.kin.steps_to_joint(self.abs_a, self.abs_b)
        return float(th), float(q)

    def true_xy(self):
        th, q = self.true_joint()
        x, y = self.kin.joint_to_xy(th, q)
        return float(x), float(y)

    def enable(self, on):
        self.enabled = on

    def set_pen(self, down):
        self.pen_down = down
        if down:
            self._cur = [self.true_xy()]
            self.trace.append(self._cur)
        else:
            self._cur = None

    def read_switch(self, name):
        if not self.cfg.v["home.use_switches"]:
            return False
        th, q = self.true_joint()
        c = self.cfg.v
        if name == "theta":
            return (th - self.kin.theta_home) * c["home.theta_dir"] >= 0
        q_home = 0.0 if c["home.r_dir"] < 0 else self.kin.travel
        return (q - q_home) * c["home.r_dir"] >= 0

    def run(self, ticks, stop, start=0, on_chunk=None):
        if not self.enabled:
            raise DriverError("Motors are disabled")
        n = len(ticks)
        if n == 0 or start >= n:
            return n
        dA = np.where(ticks.mask & 1, ticks.dir_a, 0).astype(np.int64)
        dB = np.where(ticks.mask & 2, ticks.dir_b, 0).astype(np.int64)
        cA, cB = np.cumsum(dA), np.cumsum(dB)
        offA = cA[start - 1] if start > 0 else 0
        offB = cB[start - 1] if start > 0 else 0
        reached = start
        last_t = ticks.t_us[start - 1] if start > 0 else 0
        for i0, i1 in chunk_bounds(ticks.t_us, start, 4000, MAX_US_PER_WAVE * 2):
            if stop.is_set():
                break
            if self.speed > 0:
                dt = (ticks.t_us[i1 - 1] - last_t) / 1e6 / self.speed
                if dt > 0:
                    time.sleep(min(dt, 0.25))
            last_t = ticks.t_us[i1 - 1]
            mA = self.mot_a + (cA[i0:i1] - (cA[i0 - 1] if i0 > 0 else 0))
            mB = self.mot_b + (cB[i0:i1] - (cB[i0 - 1] if i0 > 0 else 0))
            gA = self._play_gear(self.abs_a, mA, self.lash[0])
            gB = self._play_gear(self.abs_b, mB, self.lash[1])
            sel = np.arange(0, i1 - i0, max(1, (i1 - i0) // 12))
            sel = np.append(sel, i1 - i0 - 1)
            if self.pen_down and self._cur is not None:
                xs, ys = self.kin.steps_to_xy(gA[sel], gB[sel])
                self._cur.extend(zip(xs.tolist(), ys.tolist()))
            self.mot_a, self.mot_b = float(mA[-1]), float(mB[-1])
            self.abs_a, self.abs_b = float(gA[-1]), float(gB[-1])
            self.phys_steps += int(((ticks.mask[i0:i1] & 1) > 0).sum() + ((ticks.mask[i0:i1] & 2) > 0).sum())
            reached = i1
            if on_chunk and on_chunk(i1) is False:
                break
        return reached

    @staticmethod
    def _play_gear(g0: float, m: np.ndarray, lash: float) -> np.ndarray:
        """Gear position follows the motor through a dead band of width `lash`."""
        if lash <= 0:
            return m.astype(float)
        h = lash / 2.0
        out = np.empty(len(m))
        g = g0
        for k, mv in enumerate(m.tolist()):
            if g > mv + h:
                g = mv + h
            elif g < mv - h:
                g = mv - h
            out[k] = g
        return out

    def abort_hard(self):
        self.enabled = False

    def close(self):
        pass


def make_driver(cfg: Config, simulate: bool, sim_speed: float = 20.0) -> BaseDriver:
    return SimDriver(cfg, speed=sim_speed) if simulate else PigpioDriver(cfg)
