"""Desktop launcher: runs the controller on this machine and shows it in its own window.

    python -m plotter.app          # real machine
    python -m plotter.app --sim    # simulator, no hardware needed

The controller listens on 127.0.0.1 only (plain HTTP, so there is no certificate warning and
nothing else on the network can reach it). Closing the window stops the controller, unless a job
is still running, in which case the window simply comes back.
"""
from __future__ import annotations

import argparse
import fcntl
import json
import os
import shutil
import signal
import subprocess
import sys
import time
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
STATE = os.path.join(os.path.expanduser("~"), ".cache", "pen-plotter")
BROWSERS = ("chromium", "chromium-browser", "google-chrome", "chrome")
ACTIVE = ("running", "paused", "homing", "moving")


def tell(msg: str, title: str = "Pen plotter") -> None:
    """Show a problem where someone at the screen will see it (and on stderr)."""
    sys.stderr.write(msg + "\n")
    if shutil.which("zenity"):
        subprocess.run(["zenity", "--error", "--title", title, "--no-markup", "--width", "420", "--text", msg], check=False)
    elif shutil.which("notify-send"):
        subprocess.run(["notify-send", title, msg], check=False)


def find_browser() -> str | None:
    env = os.environ.get("PLOTTER_BROWSER")          # override (also used by the tests)
    if env:
        return env
    for b in BROWSERS:
        p = shutil.which(b)
        if p:
            return p
    return None


def get_status(port: int):
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/api/status", timeout=1.5) as r:
            return json.load(r)
    except Exception:
        return None


def open_window(browser: str, url: str, profile: str) -> int:
    args = [browser, f"--app={url}", f"--user-data-dir={profile}", "--no-first-run", "--no-default-browser-check",
            "--password-store=basic", "--disable-features=Translate", "--disable-session-crashed-bubble", "--start-maximized"]
    return subprocess.run(args, check=False).returncode


def log_tail(path: str, n: int = 12) -> str:
    try:
        with open(path, errors="replace") as fh:
            return "".join(fh.readlines()[-n:]).strip()
    except OSError:
        return ""


def stop(proc: subprocess.Popen) -> None:
    if proc.poll() is not None:
        return
    proc.send_signal(signal.SIGINT)                  # lets the controller turn the motors off cleanly
    try:
        proc.wait(10)
    except subprocess.TimeoutExpired:
        proc.terminate()
        try:
            proc.wait(5)
        except subprocess.TimeoutExpired:
            proc.kill()


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Pen plotter desktop app")
    ap.add_argument("--sim", action="store_true", help="simulator instead of the real machine")
    ap.add_argument("--port", type=int, default=None)
    ap.add_argument("--config", default=os.path.join(ROOT, "config.yaml"))
    ap.add_argument("--wait", type=float, default=60.0, help="seconds to wait for the controller to start")
    a = ap.parse_args(argv)

    port = a.port or (8766 if a.sim else 8765)
    url = f"http://127.0.0.1:{port}/"
    browser = find_browser()
    if not browser:
        tell("Chromium isn't installed. Run ./install-app.sh in the pen-plotter folder, or: sudo apt install chromium")
        return 1
    if not (os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY") or os.environ.get("PLOTTER_BROWSER")):
        tell("There's no desktop session to open a window in. Run this from the Pi's desktop, not from a remote shell.")
        return 1
    os.makedirs(STATE, exist_ok=True)
    profile = os.path.join(STATE, "browser-sim" if a.sim else "browser")

    # A second launch while one is already open just brings the existing window forward.
    lock = open(os.path.join(STATE, "sim.lock" if a.sim else "app.lock"), "w")
    try:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        open_window(browser, url, profile)
        return 0

    if not a.sim and shutil.which("systemctl") and subprocess.run(
            ["systemctl", "is-active", "--quiet", "pen-plotter"], check=False).returncode == 0:
        tell("The background 'pen-plotter' service is already running and controls the hardware.\n"
             "Stop it first:  sudo systemctl stop pen-plotter\n"
             "(or open its page in a browser instead).")
        return 1

    srv = None
    server_log = os.path.join(STATE, "server-sim.log" if a.sim else "server.log")
    if get_status(port) is None:
        cmd = [sys.executable, "-m", "plotter", "--config", a.config, "--host", "127.0.0.1", "--port", str(port), "--no-https"]
        if a.sim:
            cmd.append("--sim")
        with open(server_log, "wb") as lg:
            srv = subprocess.Popen(cmd, cwd=ROOT, stdout=lg, stderr=subprocess.STDOUT, start_new_session=True)
        end = time.time() + a.wait
        while get_status(port) is None:
            if srv.poll() is not None or time.time() > end:
                why = log_tail(server_log) or "No output. Is the pigpio daemon running?  (sudo systemctl start pigpiod)"
                stop(srv)
                tell("The plotter controller didn't start.\n\n" + why)
                return 1
            time.sleep(0.25)

    signal.signal(signal.SIGTERM, lambda *_: sys.exit(0))
    try:
        while True:
            open_window(browser, url, profile)
            st = get_status(port)
            if st and st.get("state") in ACTIVE:     # never stop the machine mid-move because a window was closed
                time.sleep(1)
                continue
            break
    finally:
        if srv is not None:
            stop(srv)
    return 0


if __name__ == "__main__":
    sys.exit(main())
