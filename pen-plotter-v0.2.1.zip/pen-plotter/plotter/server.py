"""HTTPS web server + REST API."""
from __future__ import annotations

import argparse
import base64
import os
import secrets
import shutil
import socket
import subprocess
import sys
import tempfile
import threading
import time

import numpy as np
import uvicorn
import yaml
from fastapi import Body, FastAPI, File, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse, JSONResponse, Response
from fastapi.staticfiles import StaticFiles

from . import __version__
from .config import BY_KEY, META_KEY, Config, ConfigError, SCHEMA, validate, validate_values
from .geometry import load_drawing
from .hardware import DriverError, make_driver
from .kinematics import Kinematics
from .layout import LayoutOptions, apply_layout
from .machine import Machine, MachineError
from .planner import plan_job

HERE = os.path.dirname(os.path.abspath(__file__))
EXAMPLES = os.path.join(HERE, "examples")


# ---------------------------------------------------------------------------
def _flat(P: np.ndarray, step: float) -> list:
    """Decimate a polyline for the browser preview and flatten to [x0,y0,x1,y1,...]."""
    if len(P) > 2:
        s = np.concatenate([[0], np.cumsum(np.hypot(*(P[1:] - P[:-1]).T))])
        k = np.floor(s / step).astype(np.int64)
        keep = np.ones(len(P), bool)
        keep[1:] = k[1:] != k[:-1]
        keep[-1] = True
        P = P[keep]
    return np.round(P, 2).ravel().tolist()


class AppState:
    def __init__(self, cfg: Config, machine: Machine, simulate: bool, sim_speed: float):
        self.cfg, self.machine, self.simulate, self.sim_speed = cfg, machine, simulate, sim_speed
        self.drawing = None
        self.filename = ""
        self.opts = LayoutOptions()
        self.plan = None
        self.plan_version = -1
        self.cfg_version = 0
        self.lock = threading.RLock()


def _pins(cfg):
    return {k: v for k, v in cfg.v.items() if k.startswith("pins.") or k in ("motors.a_invert", "motors.b_invert", "motors.enable_active_low", "home.use_switches")}


def cert_names():
    names = {"localhost", socket.gethostname(), socket.gethostname() + ".local"}
    ips = {"127.0.0.1"}
    try:
        out = subprocess.run(["hostname", "-I"], capture_output=True, text=True, timeout=3).stdout.split()
        ips.update(i for i in out if "." in i)
    except Exception:
        pass
    return sorted(names), sorted(ips)


def ensure_cert(cert_dir: str):
    os.makedirs(cert_dir, exist_ok=True)
    cert, key = os.path.join(cert_dir, "cert.pem"), os.path.join(cert_dir, "key.pem")
    if os.path.exists(cert) and os.path.exists(key):
        # regenerate if it expires within 30 days
        r = subprocess.run(["openssl", "x509", "-checkend", str(30 * 86400), "-noout", "-in", cert], capture_output=True)
        if r.returncode == 0:
            return cert, key
    if not shutil.which("openssl"):
        raise SystemExit("openssl is required to create the HTTPS certificate (sudo apt install openssl).")
    names, ips = cert_names()
    san = ",".join([f"DNS:{n}" for n in names] + [f"IP:{i}" for i in ips])
    subprocess.run(["openssl", "req", "-x509", "-newkey", "rsa:2048", "-nodes", "-days", "3650",
                    "-keyout", key, "-out", cert, "-subj", "/CN=pen-plotter", "-addext", f"subjectAltName={san}"],
                   check=True, capture_output=True)
    os.chmod(key, 0o600)
    return cert, key


# ---------------------------------------------------------------------------
def create_app(cfg_path: str, simulate: bool, sim_speed: float = 20.0, password: str | None = None) -> FastAPI:
    cfg = Config.load(cfg_path)
    errs, _ = validate(cfg)
    if errs:
        raise SystemExit("Invalid config: " + "; ".join(errs))
    driver = make_driver(cfg, simulate, sim_speed)
    machine = Machine(cfg, driver)
    st = AppState(cfg, machine, simulate, sim_speed)
    app = FastAPI(title="Pen plotter", docs_url=None, redoc_url=None)
    app.state.st = st

    @app.middleware("http")
    async def no_cache(request: Request, call_next):
        """Never let the browser cache the page, stylesheet or script.

        Without this, updating the software on the Pi leaves the old interface
        on screen until someone force-reloads, which looks exactly like the
        update not having worked.
        """
        resp = await call_next(request)
        resp.headers["Cache-Control"] = "no-store, must-revalidate"
        resp.headers["Pragma"] = "no-cache"
        return resp

    if password:
        @app.middleware("http")
        async def auth(request: Request, call_next):
            h = request.headers.get("authorization", "")
            ok = False
            if h.startswith("Basic "):
                try:
                    user_pass = base64.b64decode(h[6:]).decode()
                    ok = secrets.compare_digest(user_pass.split(":", 1)[-1], password)
                except Exception:
                    ok = False
            if not ok:
                return Response(status_code=401, headers={"WWW-Authenticate": 'Basic realm="Pen plotter"'})
            return await call_next(request)

    @app.on_event("shutdown")
    def _shutdown():
        machine.shutdown()

    def err(e: Exception, code=400):
        raise HTTPException(code, str(e))

    # ---------------------------------------------------------------- status
    @app.get("/api/status")
    def status():
        s = st.machine.status()
        s["has_drawing"] = st.drawing is not None
        s["has_plan"] = st.plan is not None and st.plan_version == st.cfg_version
        s["version"] = __version__
        return s

    @app.get("/api/trace")
    def trace(since: int = 0):
        t = st.machine.trace
        return dict(n=len(t), points=t[since:since + 20000], reset=since > len(t))

    @app.get("/api/logs")
    def logs():
        return list(st.machine.logs)

    # ---------------------------------------------------------------- config
    def cfg_payload(c: Config, extra_errs=None):
        errs, warns = validate(c) if c is st.cfg else validate_values(c.v)
        kin = Kinematics(c)
        rep = kin.report()
        rep["theta_min_deg"], rep["theta_max_deg"] = c["limits.theta_min_deg"], c["limits.theta_max_deg"]
        return dict(fields=c.schema_json(), errors=(extra_errs or []) + errs, warnings=warns, report=rep,
                    confirmed=c.confirmed, paper=dict(w=c["paper.width_mm"], h=c["paper.height_mm"],
                                                      ox=c["paper.origin_x_mm"], oy=c["paper.origin_y_mm"]),
                    offset=c["screw.offset_mm"])

    @app.get("/api/config")
    def get_config():
        return cfg_payload(st.cfg)

    @app.post("/api/config/check")
    def check_config(values: dict = Body(...)):
        try:
            c = Config(dict(st.cfg.v))
            c.update(values)
            return cfg_payload(c)
        except ConfigError as e:
            return dict(errors=[str(e)], warnings=[], report=None)

    @app.post("/api/config")
    def set_config(body: dict = Body(...)):
        values = body.get("values", {})
        if st.machine.busy:
            err(MachineError("Machine is busy"), 409)
        try:
            before = _pins(st.cfg)
            new = Config(dict(st.cfg.v), st.cfg.path)
            new.update(values)
            if body.get("confirm"):
                new.update({"meta.confirmed": True})
        except ConfigError as e:
            err(e)
        with st.lock:
            st.cfg.v = new.v
            try:
                st.cfg.save()
            except Exception as e:
                err(e, 500)
            new_driver = None
            if not st.simulate and _pins(st.cfg) != before:
                try:
                    st.machine.drv.close()
                    new_driver = make_driver(st.cfg, False)
                except DriverError as e:
                    err(e, 500)
            try:
                st.machine.reload(new_driver)
            except MachineError as e:
                err(e, 409)
            st.cfg_version += 1
            st.plan = None
        return cfg_payload(st.cfg)

    @app.post("/api/config/export")
    def export_config(values: dict = Body(default={})):
        """Download every drive setting as a YAML file. `values` carries unsaved edits from the form."""
        try:
            c = Config(dict(st.cfg.v))
            c.update(values)
        except ConfigError as e:
            err(e)
        nested = c.to_nested()
        nested.pop("meta", None)              # a loaded file must be reviewed and saved again
        lines = ["# Pen plotter drive settings",
                 "# Exported " + time.strftime("%Y-%m-%d %H:%M"),
                 "# Load it from Setup > Settings file, or copy it over config.yaml on the Pi.", ""]
        for sec, body in nested.items():
            lines.append(f"{sec}:")
            for name, val in body.items():
                f = BY_KEY[f"{sec}.{name}"]
                item = yaml.safe_dump({name: val}, default_flow_style=True, width=1000).strip()
                item = item[1:-1] if item.startswith("{") else item     # "{a: 1}" -> "a: 1"
                lines.append(f"  {item}  # {f.label}" + (f" ({f.unit})" if f.unit else ""))
            lines.append("")
        fname = time.strftime("plotter-settings-%Y-%m-%d.yaml")
        return Response("\n".join(lines), media_type="application/x-yaml",
                        headers={"Content-Disposition": f'attachment; filename="{fname}"'})

    @app.post("/api/config/import")
    def import_config(body: dict = Body(...)):
        """Parse a settings file and return the values it holds. Nothing is saved until the user presses Save."""
        try:
            data = yaml.safe_load(str(body.get("text", "")))
        except yaml.YAMLError:
            err(ValueError("That file isn't valid YAML or JSON."))
        if not isinstance(data, dict):
            err(ValueError("That doesn't look like a plotter settings file."))
        flat = {}
        for k, v in data.items():
            if isinstance(v, dict):
                for n, x in v.items():
                    flat[f"{k}.{n}"] = x
            else:
                flat[str(k)] = v
        known = {k: v for k, v in flat.items() if k in BY_KEY}
        ignored = [k for k in flat if k not in BY_KEY and k != META_KEY]
        if not known:
            err(ValueError("No plotter settings found in that file."))
        try:
            c = Config(dict(st.cfg.v))
            c.update(known)
        except ConfigError as e:
            err(e)
        return dict(values={k: c.v[k] for k in known}, ignored=ignored)

    # ----------------------------------------------------------------- files
    def _load_path(path, name):
        try:
            d = load_drawing(path)
        except Exception as e:
            err(ValueError(f"Couldn't read {name}: {e}"))
        st.drawing, st.filename, st.plan = d, name, None
        x0, y0, x1, y1 = d.bbox()
        return dict(name=name, strokes=len(d.strokes), points=int(sum(len(s) for s in d.strokes)),
                    width_mm=x1 - x0, height_mm=y1 - y0, warnings=d.warnings)

    @app.post("/api/upload")
    async def upload(file: UploadFile = File(...)):
        ext = os.path.splitext(file.filename or "")[1].lower()
        if ext not in (".svg", ".dxf"):
            err(ValueError("Use an .svg or .dxf file"))
        data = await file.read()
        if len(data) > 60_000_000:
            err(ValueError("File is larger than 60 MB"))
        with tempfile.NamedTemporaryFile(suffix=ext, delete=False) as tf:
            tf.write(data)
            tmp = tf.name
        try:
            return _load_path(tmp, file.filename)
        finally:
            os.unlink(tmp)

    @app.get("/api/examples")
    def examples():
        return sorted(f for f in os.listdir(EXAMPLES) if f.lower().endswith((".svg", ".dxf")))

    @app.post("/api/examples/{name}")
    def load_example(name: str):
        p = os.path.join(EXAMPLES, os.path.basename(name))
        if not os.path.exists(p):
            err(ValueError("No such example"), 404)
        return _load_path(p, name)

    @app.delete("/api/drawing")
    def remove_drawing():
        if st.machine.busy:
            err(MachineError("Machine is busy"), 409)
        with st.lock:
            st.drawing, st.filename, st.plan = None, "", None
        return status()

    # ------------------------------------------------------------------ plan
    @app.post("/api/plan")
    def make_plan(opts: dict = Body(default={})):
        if st.drawing is None:
            err(ValueError("Load a drawing first"))
        with st.lock:
            st.opts = LayoutOptions.from_dict(opts)
            c = st.cfg
            kin = st.machine.kin
            n_total = len(st.drawing.strokes)
            gone = set(st.opts.exclude)
            keep = [i for i in range(n_total) if i not in gone]
            if not keep:
                err(ValueError("Every line has been removed from the job."))
            strokes, info = apply_layout([st.drawing.strokes[i] for i in keep], st.opts, c, kin)
            plan = plan_job(strokes, kin, c, st.machine.park_steps())
            st.plan, st.plan_version = plan, st.cfg_version
            npts = sum(len(s) for s in strokes) + sum(len(s) for s in plan.preview)
            step = max(0.2, npts / 150_000 * 0.4)
            warns = list(st.drawing.warnings) + plan.warnings
            if info.get("note"):
                warns.append(info["note"])
            if not info["fits_paper"]:
                warns.append("The drawing extends past the edge of the paper.")
            return dict(info=info, stats=plan.stats, warnings=warns,
                        intended=[_flat(s, step) for s in strokes],
                        drawn=[_flat(s, step) for s in plan.preview],
                        travels=[[round(v, 1) for v in t] for t in plan.travels[:5000]],
                        indices=keep, total=n_total, opts=st.opts.to_dict())

    # ------------------------------------------------------------ machine ops
    def op(fn, *a, **k):
        try:
            fn(*a, **k)
        except MachineError as e:
            err(e, 409)
        return status()

    @app.post("/api/home")
    def home():
        return op(st.machine.home)

    @app.post("/api/set_zero")
    def set_zero():
        return op(st.machine.set_zero)

    @app.post("/api/park")
    def park():
        return op(st.machine.park)

    @app.post("/api/motors")
    def motors(body: dict = Body(...)):
        return op(st.machine.motors, bool(body.get("on")))

    @app.post("/api/pen")
    def pen(body: dict = Body(...)):
        return op(st.machine.pen, bool(body.get("down")))

    @app.post("/api/jog")
    def jog(body: dict = Body(...)):
        kind = body.get("kind")
        if kind == "theta":
            return op(st.machine.move_to_joint, dtheta_deg=float(body["amount"]))
        if kind == "r":
            return op(st.machine.move_to_joint, dq_mm=float(body["amount"]))
        if kind == "xy":
            return op(st.machine.goto_xy, float(body["x"]), float(body["y"]))
        if kind == "motor":
            m = body.get("motor")
            if m not in ("a", "b"):
                err(ValueError("motor must be a or b"))
            return op(st.machine.nudge_motor, m, int(body["steps"]))
        err(ValueError("unknown jog kind"))

    @app.post("/api/job/start")
    def job_start():
        if st.plan is None or st.plan_version != st.cfg_version:
            err(ValueError("Plan is out of date. Adjust placement to regenerate it."))
        return op(st.machine.run_job, st.plan)

    @app.post("/api/job/pause")
    def job_pause():
        st.machine.pause()
        return status()

    @app.post("/api/job/resume")
    def job_resume():
        st.machine.resume()
        return status()

    @app.post("/api/job/stop")
    def job_stop():
        st.machine.stop()
        return status()

    @app.post("/api/estop")
    def estop():
        st.machine.estop()
        return status()

    @app.post("/api/clear_error")
    def clear_error():
        st.machine.clear_error()
        return status()

    app.mount("/", StaticFiles(directory=os.path.join(HERE, "static"), html=True), name="static")
    return app


# ---------------------------------------------------------------------------
def main(argv=None):
    ap = argparse.ArgumentParser(description="Differential-swerve pen plotter controller")
    ap.add_argument("--config", default="config.yaml")
    ap.add_argument("--sim", action="store_true", help="simulate the machine (no GPIO needed)")
    ap.add_argument("--sim-speed", type=float, default=20.0, help="simulator speed multiplier (0 = instant)")
    ap.add_argument("--host", default="0.0.0.0")
    ap.add_argument("--port", type=int, default=None)
    ap.add_argument("--password", default=os.environ.get("PLOTTER_PASSWORD"), help="optional web password (username ignored)")
    ap.add_argument("--no-https", action="store_true", help="serve plain HTTP (development only)")
    ap.add_argument("--cert-dir", default=None)
    a = ap.parse_args(argv)

    cfg_path = os.path.abspath(a.config)
    cfg = Config.load(cfg_path)
    if not os.path.exists(cfg_path):
        cfg.save(cfg_path)
    port = a.port or cfg["server.port"]
    app = create_app(cfg_path, a.sim, a.sim_speed, a.password)
    kw = {}
    scheme = "http"
    if not a.no_https:
        cert, key = ensure_cert(a.cert_dir or os.path.join(os.path.dirname(cfg_path), "certs"))
        kw = dict(ssl_certfile=cert, ssl_keyfile=key)
        scheme = "https"
    names, ips = cert_names()
    print(f"\n  Pen plotter v{__version__} ({'SIMULATOR' if a.sim else 'hardware'}) is up. Open one of:")
    for i in ips:
        if i != "127.0.0.1":
            print(f"    {scheme}://{i}:{port}")
    print(f"    {scheme}://{socket.gethostname()}.local:{port}")
    if scheme == "https":
        print("  Your browser will warn about the self-signed certificate: choose Advanced, then Proceed.\n")
    uvicorn.run(app, host=a.host, port=port, log_level="warning", **kw)


if __name__ == "__main__":
    main()
