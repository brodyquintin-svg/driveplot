"""Generate the bundled example drawings."""
import math, os
import ezdxf

out = os.path.join(os.path.dirname(os.path.abspath(__file__)), "plotter", "examples")
os.makedirs(out, exist_ok=True)

# --- calibration.svg: 100 mm square, circle, diagonals, ticks, asymmetric L marker
svg = ['<svg xmlns="http://www.w3.org/2000/svg" width="100mm" height="100mm" viewBox="0 0 100 100" fill="none" stroke="#000" stroke-width="0.3">',
       '<rect x="0" y="0" width="100" height="100"/>',
       '<circle cx="50" cy="50" r="40"/>', '<circle cx="50" cy="50" r="20"/>',
       '<path d="M0 0 L100 100 M0 100 L100 0"/>',
       '<path d="M50 0 V100 M0 50 H100"/>']
for i in range(10, 100, 10):
    svg.append(f'<path d="M{i} 0 v3 M{i} 100 v-3 M0 {i} h3 M100 {i} h-3"/>')
svg.append('<path d="M8 8 V30 H20"/>')   # "L" in the top-left shows orientation (SVG y is down)
svg.append('</svg>')
open(os.path.join(out, "calibration.svg"), "w").write("\n".join(svg))

# --- spirograph.svg: hypotrochoid
R, r, d = 50, 17, 35
pts = []
for i in range(0, 3601):
    t = i / 3600 * 2 * math.pi * 17
    x = (R - r) * math.cos(t) + d * math.cos((R - r) / r * t)
    y = (R - r) * math.sin(t) - d * math.sin((R - r) / r * t)
    pts.append(f"{x + 100:.3f},{y + 100:.3f}")
open(os.path.join(out, "spirograph.svg"), "w").write(
    f'<svg xmlns="http://www.w3.org/2000/svg" width="200mm" height="200mm" viewBox="0 0 200 200">'
    f'<polyline fill="none" stroke="#000" stroke-width="0.3" points="{" ".join(pts)}"/></svg>')

# --- test.dxf: mixed entity types
doc = ezdxf.new("R2010", setup=True)
doc.units = ezdxf.units.MM
msp = doc.modelspace()
msp.add_lwpolyline([(0, 0), (80, 0), (80, 50), (0, 50)], close=True)
msp.add_circle((40, 25), 20)
msp.add_arc((40, 25), 30, 20, 160)
msp.add_line((0, 0), (80, 50))
msp.add_spline([(0, 60), (20, 80), (40, 55), (60, 85), (80, 60)])
msp.add_ellipse((40, 110), major_axis=(30, 0), ratio=0.4)
doc.saveas(os.path.join(out, "test_shapes.dxf"))
print("examples written to", out)
