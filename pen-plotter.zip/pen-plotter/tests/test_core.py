import math, sys, time
import os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import numpy as np
from plotter.config import Config, ConfigError, validate
from plotter.kinematics import Kinematics
from plotter.hardware import SimDriver
from plotter.machine import Machine
from plotter.planner import plan_job, motion_from_draw, build_ticks
from plotter.layout import LayoutOptions, apply_layout


def base(**o):
    d = {"screw.r_home_mm": 50, "screw.length_mm": 260, "screw.unusable_mm": 20, "paper.width_mm": 180, "paper.height_mm": 180,
         "paper.origin_x_mm": 40, "paper.origin_y_mm": 10, "pen.settle_s": 0.0, "motors.idle_disable_s": 0}
    d.update(o)
    return Config(d)


def wait(m):
    while m.busy:
        time.sleep(0.005)
    assert m.state != "error", m.message


def test_kinematics_roundtrip():
    for over in ({}, {"screw.offset_mm": 12}, {"kin.theta_sign": -1, "kin.r_sign": -1}):
        k = Kinematics(base(**over))
        x = np.array([100., 50, 150]); y = np.array([100., 150, 20])
        a, b = k.xy_to_steps(x, y)
        x2, y2 = k.steps_to_xy(a, b)
        assert np.abs(x - x2).max() < 1e-9 and np.abs(y - y2).max() < 1e-9


def test_pure_swing_does_not_extend():
    k = Kinematics(base())
    th, q = k.steps_to_joint(1000.0, 1000.0)
    assert abs(q) < 1e-9 and th != 0


def test_pure_r_does_not_swing():
    k = Kinematics(base())
    th, q = k.steps_to_joint(1000.0, -1000.0)
    assert abs(th - k.theta_home) < 1e-9 and q != 0


def test_config_validation():
    import pytest
    with pytest.raises(ConfigError):
        Config({"screw.length_mm": 10, "screw.unusable_mm": 20})
    with pytest.raises(ConfigError):
        Config({"pins.a_dir": 17})          # same GPIO as motor A STEP
    with pytest.raises(ConfigError):
        Config({"motors.microsteps": 3})
    errs, warns = validate(Config())
    assert not errs and warns               # defaults are valid but flagged as unconfirmed


def test_closed_circle_nets_zero_steps():
    cfg = base(); k = Kinematics(cfg)
    t = np.linspace(0, 2 * np.pi, 300)
    plan = plan_job([np.c_[130 + 35 * np.cos(t), 100 + 35 * np.sin(t)]], k, cfg, (0, 0))
    dp = [o[1] for o in plan.ops if o[0] == "draw"][0]
    tk = build_ticks(motion_from_draw(dp))
    assert tk.net == (0, 0)
    assert (np.diff(tk.t_us) >= 10).all()


def test_rate_limit_respected():
    cfg = base(**{"motion.max_step_rate_hz": 8000}); k = Kinematics(cfg)
    plan = plan_job([np.array([[60, 40], [200, 40.]])], k, cfg, (0, 0))
    dp = [o[1] for o in plan.ops if o[0] == "draw"][0]
    tk = build_ticks(motion_from_draw(dp))
    for bit in (1, 2):
        t = tk.t_us[(tk.mask & bit) > 0]
        assert np.diff(t).min() >= 1e6 / 8000 * 0.9


def test_sim_home_and_draw_accuracy():
    cfg = base(); drv = SimDriver(cfg, speed=0); m = Machine(cfg, drv)
    m.home(); wait(m)
    x, y = m.pose()[2:]; tx, ty = drv.true_xy()
    assert math.hypot(x - tx, y - ty) < 0.3
    t = np.linspace(0, 2 * np.pi, 300)
    sq = np.array([[70, 30], [190, 30], [190, 150], [70, 150], [70, 30.]])
    circ = np.c_[130 + 35 * np.cos(t), 100 + 35 * np.sin(t)]
    plan = plan_job([circ, sq], m.kin, cfg, m.park_steps())
    m.run_job(plan); wait(m)
    ink = np.vstack([np.array(s) for s in drv.trace if len(s) > 1])
    dc = np.abs(np.hypot(ink[:, 0] - 130, ink[:, 1] - 100) - 35)
    ds = np.minimum.reduce([np.abs(ink[:, 1] - 30), np.abs(ink[:, 1] - 150), np.abs(ink[:, 0] - 70), np.abs(ink[:, 0] - 190)])
    assert np.minimum(dc, ds).max() < 0.15


def test_reach_layout_has_no_clipping():
    cfg = Config({"screw.r_home_mm": 60, "screw.length_mm": 300, "screw.unusable_mm": 20, "paper.width_mm": 210,
                  "paper.height_mm": 297, "paper.origin_x_mm": 40})
    k = Kinematics(cfg)
    sq = [np.array([[0, 0], [100, 0], [100, 100], [0, 100], [0, 0.]])]
    st, info = apply_layout(sq, LayoutOptions(fit="reach"), cfg, k)
    plan = plan_job(st, k, cfg, (0, 0))
    assert plan.stats["clipped_mm"] == 0


def test_stop_midstroke_keeps_position():
    cfg = base(); drv = SimDriver(cfg, speed=30); m = Machine(cfg, drv)
    m.home(); wait(m)
    plan = plan_job([np.array([[70, 40], [190, 40], [190, 150.]])], m.kin, cfg, m.park_steps())
    m.run_job(plan); time.sleep(0.6); m.stop(); wait(m)
    x, y = m.pose()[2:]; tx, ty = drv.true_xy()
    assert math.hypot(x - tx, y - ty) < 0.3
    assert not m.pen_down


def test_pause_resume_completes_cleanly():
    cfg = base(); drv = SimDriver(cfg, speed=30); m = Machine(cfg, drv)
    m.home(); wait(m)
    t = np.linspace(0, 2 * np.pi, 300)
    circ = np.c_[130 + 35 * np.cos(t), 100 + 35 * np.sin(t)]
    plan = plan_job([circ], m.kin, cfg, m.park_steps())
    m.run_job(plan); time.sleep(0.5)
    m.pause(); time.sleep(0.6)
    assert m.state == "paused" and not m.pen_down
    m.resume(); wait(m)
    assert m.state == "idle" and m.job["finished"]
    ink = np.vstack([np.array(s) for s in drv.trace if len(s) > 1])
    dev = np.abs(np.hypot(ink[:, 0] - 130, ink[:, 1] - 100) - 35)
    assert dev.max() < 0.2
    assert len([s for s in drv.trace if len(s) > 1]) == 2       # pen lifted once for the pause
