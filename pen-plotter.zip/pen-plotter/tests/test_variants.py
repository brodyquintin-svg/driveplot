import sys, math, time
import os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import numpy as np, itertools
from plotter.config import Config
from plotter.hardware import SimDriver
from plotter.machine import Machine
from plotter.planner import plan_job

def wait(m):
    while m.busy: time.sleep(0.005)
    assert m.state != 'error', m.message

def run(over, lash=(0,0)):
    base={"screw.r_home_mm":50,"screw.length_mm":260,"screw.unusable_mm":20,"paper.width_mm":180,"paper.height_mm":180,
          "paper.origin_x_mm":40,"paper.origin_y_mm":10,"pen.settle_s":0.0,"motors.idle_disable_s":0}
    base.update(over)
    cfg=Config(base); drv=SimDriver(cfg,speed=0,lash=lash); m=Machine(cfg,drv)
    m.home(); wait(m)
    th,q,x,y=m.pose(); tx,ty=drv.true_xy()
    assert math.hypot(x-tx,y-ty)<0.3+max(lash)*0.06,(x,y,tx,ty)
    t=np.linspace(0,2*np.pi,300)
    strokes=[np.c_[130+35*np.cos(t),100+35*np.sin(t)], np.array([[70,30],[190,30],[190,150],[70,150],[70,30.]])]
    plan=plan_job(strokes,m.kin,cfg,m.park_steps()); assert plan.stats['clipped_mm']<1, plan.warnings
    m.run_job(plan); wait(m)
    assert all(abs(a-b)<0.3+max(lash)*0.06 for a,b in zip(m.pose()[2:],drv.true_xy())), (m.pose(),drv.true_xy())
    # ink check vs ideal circle radius
    ink=np.vstack([np.array(s) for s in drv.trace if len(s)>1])
    # farthest deviation from either the circle or square boundary
    dc=np.abs(np.hypot(ink[:,0]-130,ink[:,1]-100)-35)
    ds=np.minimum.reduce([np.abs(ink[:,1]-30),np.abs(ink[:,1]-150),np.abs(ink[:,0]-70),np.abs(ink[:,0]-190)])
    dev=np.minimum(dc,ds).max()
    return dev

cases=[dict(),
 {"kin.theta_sign":-1},{"kin.r_sign":-1},{"kin.theta_sign":-1,"kin.r_sign":-1},
 {"home.theta_dir":1,"home.theta_deg":95,"limits.theta_min_deg":-2,"limits.theta_max_deg":93},
 {"screw.offset_mm":12},
 {"gears.b_drive_pd_mm":20,"gears.b_driven_pd_mm":50},
 {"motors.microsteps":8,"motion.max_step_rate_hz":12000},
 {"home.r_dir":1},
]
for c in cases:
    print("%-70s dev %.3f mm"%(c, run(c)))
lash=(6,9)
print("lash 6/9 steps, no compensation:   dev %.3f mm"%run({}, lash))
print("lash 6/9 steps, with compensation: dev %.3f mm"%run({"motion.backlash_a_steps":6,"motion.backlash_b_steps":9}, lash))
