import sys, time, math
import os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import numpy as np
from plotter.config import Config
from plotter.hardware import SimDriver
from plotter.machine import Machine
from plotter.planner import plan_job

def wait(m, t=120):
    t0=time.time()
    while m.busy and time.time()-t0<t: time.sleep(0.01)
    assert not m.busy
    if m.state=='error': raise SystemExit("ERROR: "+m.message)

cfg = Config({"screw.r_home_mm":40,"screw.length_mm":260,"screw.unusable_mm":20,"paper.width_mm":200,"paper.height_mm":200,
              "paper.origin_x_mm":30,"paper.origin_y_mm":0, "limits.theta_min_deg":-2,"limits.theta_max_deg":92,
              "pen.settle_s":0.0, "motors.idle_disable_s":0})
drv = SimDriver(cfg, speed=0)
m = Machine(cfg, drv)
m.home(); wait(m)
th,q,x,y = m.pose(); tx,ty = drv.true_xy()
print("homed pose", m.pose(), "true xy", tx,ty, "err", math.hypot(x-tx,y-ty))
assert math.hypot(x-tx,y-ty) < 0.01
# drawing: circle + square + a diagonal line
t=np.linspace(0,2*np.pi,400)
circ=np.c_[130+45*np.cos(t),100+45*np.sin(t)]
sq=np.array([[60,40],[200,40],[200,170],[60,170],[60,40.]])
diag=np.array([[60,40],[200,170.]])
plan = plan_job([circ,sq,diag], m.kin, cfg, m.park_steps())
print(plan.stats, plan.warnings)
t0=time.time(); m.run_job(plan); wait(m); print("job wall", time.time()-t0)
print("end pose", m.pose()[2:], "true", drv.true_xy(), "steps", m.pos)
# compare traced ink to ideal polylines
def dist_to_polylines(pts, polys):
    best=np.full(len(pts), np.inf)
    for P in polys:
        a=P[:-1]; b=P[1:]; ab=b-a; L2=(ab**2).sum(1)+1e-12
        for i in range(0,len(pts),2000):
            p=pts[i:i+2000,None,:]
            tt=np.clip(((p-a)*ab).sum(2)/L2,0,1)
            proj=a+tt[...,None]*ab
            d=np.hypot(*(p-proj).transpose(2,0,1)).min(1)
            best[i:i+2000]=np.minimum(best[i:i+2000],d)
    return best
ink=[np.array(s) for s in drv.trace if len(s)>1]
pts=np.vstack(ink)
ideal=[circ,sq,diag]
d=dist_to_polylines(pts, ideal)
print("ink pts",len(pts),"max dev from source %.4f mm, mean %.4f"%(d.max(), d.mean()))
# coverage: every source vertex region visited
cov=dist_to_polylines(np.vstack([densify for densify in [np.c_[np.linspace(p[0,0],p[-1,0],50),np.linspace(p[0,1],p[-1,1],50)] for p in [sq,diag]]]), ink)
print("max gap of source lines covered by ink: %.3f mm"%cov.max())
assert d.max()<0.12
