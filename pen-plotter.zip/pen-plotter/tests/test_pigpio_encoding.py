"""Play the tick stream through PigpioDriver against a fake pigpio and decode the pulses back."""
import sys, types, threading
import os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import numpy as np

class pulse:
    def __init__(self, on, off, delay): self.on, self.off, self.delay = on, off, delay

class FakePi:
    connected = True
    def __init__(self, *a): self.sent=[]; self.cur=None; self.waves={}; self.n=0; self.pend=[]; self.gpio={}; self.log=[]
    def set_mode(self,*a): pass
    def write(self,p,l): self.gpio[p]=l
    def read(self,p): return 1
    def set_pull_up_down(self,*a): pass
    def set_glitch_filter(self,*a): pass
    def wave_get_max_cbs(self): return 4992
    def wave_clear(self): self.waves={}
    def wave_add_generic(self, p): self.pend=list(p); return len(p)
    def wave_create(self):
        self.n+=1; self.waves[self.n]=self.pend; self.pend=[]; return self.n
    def wave_send_using_mode(self,w,mode): self.sent.append(w); self.cur=w
    def wave_send_once(self,w): self.sent.append(w); self.cur=w
    def wave_tx_at(self): return self.cur if self.cur is not None else 9999
    def wave_tx_busy(self): return False
    def wave_delete(self,w): assert w in self.waves; del self.waves[w]
    def wave_tx_stop(self): pass
    def set_servo_pulsewidth(self,*a): pass
    def stop(self): pass
    def decode_source(self): pass

fake = types.ModuleType("pigpio")
fake.pulse=pulse; fake.pi=FakePi; fake.OUTPUT=1; fake.INPUT=0; fake.PUD_UP=2; fake.PUD_DOWN=1
fake.WAVE_MODE_ONE_SHOT=0; fake.WAVE_MODE_ONE_SHOT_SYNC=2
sys.modules["pigpio"]=fake

from plotter.config import Config
from plotter.hardware import PigpioDriver, PULSE_US
from plotter.kinematics import Kinematics
from plotter.planner import plan_job, motion_from_draw, build_ticks

for inv in [(False,False),(True,False),(False,True)]:
    cfg=Config({"screw.r_home_mm":40,"screw.length_mm":260,"screw.unusable_mm":20,"motors.a_invert":inv[0],"motors.b_invert":inv[1],
                "motion.backlash_a_steps":5,"motion.backlash_b_steps":5})
    kin=Kinematics(cfg)
    t=np.linspace(0,2*np.pi,300); circ=np.c_[130+45*np.cos(t),100+45*np.sin(t)]
    plan=plan_job([circ, np.array([[60,40],[200,40],[200,170.]])],kin,cfg,(0,0))
    dp=[o[1] for o in plan.ops if o[0]=='draw'][0]
    c=cfg.v
    tk=build_ticks(motion_from_draw(dp),(1,-1),(5,5),c["motion.backlash_rate_hz"])
    drv=PigpioDriver(cfg)
    drv.run(tk, threading.Event())
    pi=drv.pi
    # decode: rebuild waves in order (they were deleted, so capture from history)
    # FakePi deletes waves; re-run capturing pulses instead
    captured=[]
    orig=pi.wave_create
    def cap():
        w=orig(); captured.append(list(pi.waves[w])); return w
    pi.wave_create=cap
    pi.sent.clear(); drv.run(tk, threading.Event())
    pulses=[p for w in captured[:-1] for p in w]          # last wave is the STEP-low cleanup
    g={}; tcur=0; edges=[]; 
    sa,sb=drv.stepA,drv.stepB; da,db=drv.dirA,drv.dirB
    state=0; min_high=1e9; 
    for p in pulses:
        new=(state|p.on)&~p.off
        rise=new&~state
        if rise&sa: edges.append((tcur,'A',bool(new&da)))
        if rise&sb: edges.append((tcur,'B',bool(new&db)))
        state=new; tcur+=p.delay
    ea=[e for e in edges if e[1]=='A']; eb=[e for e in edges if e[1]=='B']
    na=int((tk.mask&1>0).sum()); nb=int(((tk.mask&2)>0).sum())
    assert len(ea)==na and len(eb)==nb,(len(ea),na,len(eb),nb)
    # timing: rising edge = t - PULSE_US
    times=np.array([e[0] for e in edges]); 
    exp=[]
    for k in range(len(tk)):
        if tk.mask[k]&1: exp.append((tk.t_us[k]-PULSE_US,'A',(tk.dir_a[k]>0)^inv[0]))
        if tk.mask[k]&2: exp.append((tk.t_us[k]-PULSE_US,'B',(tk.dir_b[k]>0)^inv[1]))
    assert [e[0] for e in edges]==[e[0] for e in exp]
    assert [e[2] for e in edges]==[bool(e[2]) for e in exp]
    gaps=np.diff([e[0] for e in ea]); 
    print(f"invert={inv}: {na}+{nb} steps OK, dir pins OK, min same-motor spacing {gaps.min()} us, waves {len(captured)}, max pulses/wave {max(len(w) for w in captured)}")
print("pigpio encoding test passed")
