"use strict";
const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];

// ------------------------------------------------------------------ state
const S = {
  status: null, cfg: null, plan: null, drawingLoaded: false,
  reach: null,            // geometry for the canvas
  view: { s: 1, ox: 0, oy: 0, fitted: false },
  trace: { n: 0, path: null, last: null },
  target: null, dirty: {}, hover: null,
  sel: new Set(),         // selected strokes (original indices in the file)
  excluded: [], undo: [], // strokes removed from the job, and batches for Undo
};

// ------------------------------------------------------------------ api
async function api(path, body, method) {
  const opt = { method: method || (body === undefined ? "GET" : "POST"), headers: {} };
  if (body instanceof FormData) opt.body = body;
  else if (body !== undefined) { opt.headers["Content-Type"] = "application/json"; opt.body = JSON.stringify(body); }
  const r = await fetch(path, opt);
  let data = null;
  try { data = await r.json(); } catch (_) {}
  if (!r.ok) throw new Error((data && data.detail) ? (typeof data.detail === "string" ? data.detail : JSON.stringify(data.detail)) : `Request failed (${r.status})`);
  return data;
}
let toastTimer;
function toast(msg, bad) {
  const t = $("#toast");
  t.textContent = msg; t.className = "toast" + (bad ? " bad" : ""); t.hidden = false;
  clearTimeout(toastTimer); toastTimer = setTimeout(() => (t.hidden = true), bad ? 7000 : 2800);
}
const guard = fn => async (...a) => { try { return await fn(...a); } catch (e) { toast(e.message, true); } };
const fmtTime = s => { s = Math.round(s); const h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60); return h ? `${h} h ${m} min` : m ? `${m} min ${s % 60} s` : `${s} s`; };
const debounce = (fn, ms) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };

// ------------------------------------------------------------------ tabs
function selectTab(id) {
  $$("[role=tab]").forEach(b => b.setAttribute("aria-selected", String(b.id === "t-" + id)));
  $$("[role=tabpanel]").forEach(p => (p.hidden = p.id !== "p-" + id));
}
$$("[role=tab]").forEach(b => b.addEventListener("click", () => selectTab(b.id.slice(2))));

// ------------------------------------------------------------------ status
function renderStatus(s) {
  S.status = s;
  const st = $("#state");
  let txt, cls = "busy";
  const noSw = s.use_switches === false;
  if (s.state === "idle") { txt = s.homed ? "Ready" : (noSw ? "Zero not set" : "Not homed"); cls = s.homed ? "ready" : "idle"; }
  else if (s.state === "homing") txt = "Homing";
  else if (s.state === "moving") txt = "Moving";
  else if (s.state === "running") txt = "Drawing";
  else if (s.state === "paused") txt = "Paused";
  else { txt = "Stopped"; cls = "error"; }
  if (s.sim) txt += " (simulator)";
  st.dataset.s = cls; $("#stateText").textContent = txt;
  $("#rTheta").textContent = s.homed ? s.theta_deg.toFixed(2) + "°" : "–";
  $("#rQ").textContent = s.homed ? s.q_mm.toFixed(2) : "–";
  $("#rX").textContent = s.homed ? s.x.toFixed(2) : "–";
  $("#rY").textContent = s.homed ? s.y.toFixed(2) : "–";
  $(".switches").hidden = noSw; $("#home").hidden = noSw;
  $("#zero").classList.toggle("primary", noSw); $("#park").textContent = noSw ? "Go to zero" : "Park arm";
  $("#swTheta").classList.toggle("on", !!(s.switches && s.switches.theta));
  $("#swR").classList.toggle("on", !!(s.switches && s.switches.r));

  const busy = s.state === "homing" || s.state === "moving" || s.state === "running" || s.state === "paused";
  const running = s.state === "running", paused = s.state === "paused";
  $("#pause").hidden = !running; $("#resume").hidden = !paused; $("#stop").hidden = !(running || paused);
  $("#start").hidden = running || paused;
  let why = "";
  if (!S.drawingLoaded) why = "Load a drawing to begin.";
  else if (!S.plan) why = "Planning…";
  else if (!s.homed) why = noSw ? "Set the zero position on the Move tab first." : "Home the machine on the Move tab first.";
  else if (!s.confirmed && !s.sim) why = "Review your settings on the Setup tab and save them first.";
  else if (busy) why = "";
  else if (!S.plan.stats.n_strokes) why = "Nothing in the drawing is within reach.";
  $("#start").disabled = !!why || busy;
  $("#startWhy").textContent = s.state === "error" ? s.message : why;
  if (s.state === "error" && !$("#startWhy").querySelector("button")) {
    const b = document.createElement("button"); b.textContent = "Dismiss"; b.style.marginLeft = "8px";
    b.onclick = guard(async () => renderStatus(await api("/api/clear_error", {})));
    $("#startWhy").append(b);
  }
  const j = s.job;
  $("#progress").hidden = !j;
  if (j) {
    $("#progress").hidden = false;
    $("#bar").style.width = (j.progress * 100).toFixed(1) + "%";
    $("#progressText").textContent = j.finished ? `Finished in ${fmtTime(j.elapsed)}` :
      `${(j.progress * 100).toFixed(0)}% · ${fmtTime(j.elapsed)} elapsed · about ${fmtTime(Math.max(0, j.est_total - j.progress * j.est_total))} to go`;
  }
  $("#motorsToggle").textContent = "Motors: " + (s.motors_on ? "on" : "off");
  $("#motorsToggle").disabled = busy;
  $$("#p-move button").forEach(b => { if (b.id !== "motorsToggle") b.disabled = busy; });
  renderLineTools();
  $("#homeNote").textContent = s.homed ? "Position known." : (noSw ? "Move the arm to its zero position by hand, then press Set zero here." : "Not homed yet.");
  if (s.underruns) $("#homeNote").textContent += ` Step stream hiccups: ${s.underruns}.`;
  draw();
}

let statusBusy = false;
async function pollStatus() {
  if (!statusBusy) {
    statusBusy = true;
    try { renderStatus(await api("/api/status")); await pollTrace(); }
    catch (e) { $("#stateText").textContent = "Disconnected"; $("#state").dataset.s = "error"; }
    statusBusy = false;
  }
  const active = S.status && ["running", "homing", "moving", "paused"].includes(S.status.state);
  setTimeout(pollStatus, active ? 250 : 800);
}
async function pollTrace() {
  const s = S.status; if (!s) return;
  if (s.n_trace === S.trace.n) return;
  const r = await api(`/api/trace?since=${s.n_trace < S.trace.n ? 0 : S.trace.n}`);
  if (s.n_trace < S.trace.n) { S.trace.path = null; S.trace.last = null; S.trace.n = 0; }
  if (!S.trace.path) S.trace.path = new Path2D();
  for (const [x, y, pen] of r.points) {
    if (pen && S.trace.last && S.trace.last[2]) { S.trace.path.moveTo(S.trace.last[0], S.trace.last[1]); S.trace.path.lineTo(x, y); }
    S.trace.last = [x, y, pen];
  }
  S.trace.n += r.points.length;
  if (S.trace.n > r.n) S.trace.n = r.n;
}
async function pollLogs() {
  try { $("#logText").textContent = (await api("/api/logs")).join("\n"); } catch (_) {}
  setTimeout(pollLogs, 3000);
}

// ------------------------------------------------------------------ config / setup form
function reachFromCfg(c) {
  const r = c.report, e = c.offset || 0;
  const a0 = Math.sqrt(Math.max(r.r_min_mm ** 2 - e ** 2, 0));
  S.reach = { a0, travel: r.travel_mm, e, tmin: r.theta_min_deg, tmax: r.theta_max_deg, rmin: r.r_min_mm, rmax: r.r_max_mm, paper: c.paper };
}
function jointXY(thDeg, q) {
  const a = S.reach.a0 + q, e = S.reach.e, ang = thDeg * Math.PI / 180 + Math.atan2(e, a), rho = Math.hypot(a, e);
  return [rho * Math.cos(ang), rho * Math.sin(ang)];
}

function buildSetup(c) {
  S.cfg = c;
  const form = $("#setupForm"); form.innerHTML = "";
  const groups = {};
  c.fields.forEach(f => (groups[f.group] = groups[f.group] || []).push(f));
  const open = new Set(["Gear trains", "Bevel differential", "Lead screw"]);
  for (const [g, fs] of Object.entries(groups)) {
    const d = document.createElement("details"); if (open.has(g)) d.open = true;
    d.innerHTML = `<summary>${g}</summary><div class="fields"></div>`;
    const box = $(".fields", d);
    fs.forEach(f => {
      const w = document.createElement("div"); w.className = "fld"; w.dataset.key = f.key; if (f.needs) w.dataset.needs = f.needs;
      const id = "f_" + f.key.replace(/\./g, "_");
      let ctl;
      if (f.kind === "bool") ctl = `<input type="checkbox" id="${id}" ${f.value ? "checked" : ""}>`;
      else if (f.kind === "choice") ctl = `<select id="${id}">${f.choices.map(ch => `<option value="${ch}" ${Number(ch) === Number(f.value) ? "selected" : ""}>${ch}</option>`).join("")}</select>`;
      else ctl = `<input type="number" id="${id}" value="${f.value}" step="any">`;
      w.innerHTML = `<label for="${id}">${f.label}</label><div class="ctl">${ctl}<span class="u">${f.unit || ""}</span></div>` +
        (f.help ? `<div class="help">${f.help}</div>` : "");
      const inp = $("input,select", w);
      const onch = () => {
        let v = f.kind === "bool" ? inp.checked : inp.value;
        if (f.kind !== "bool" && v === "") return;
        S.dirty[f.key] = v; w.classList.add("changed"); applyNeeds(); checkSetup();
      };
      inp.addEventListener("input", onch); inp.addEventListener("change", onch);
      box.append(w);
    });
    form.append(d);
  }
  applyNeeds();
  renderDerived(c);
  $("#saveNote").textContent = c.confirmed ? "Settings saved." : "These are placeholder values. Check them against your build, then save to unlock drawing.";
  $("#o_speed").value = c.fields.find(f => f.key === "motion.draw_speed_mm_s").value;
}
// Hide settings that only matter when another (checkbox) setting is on, e.g. the limit-switch pins.
function applyNeeds() {
  $$("#setupForm .fld[data-needs]").forEach(w => {
    const dep = $("#f_" + w.dataset.needs.replace(/\./g, "_"));
    w.hidden = !(dep && dep.checked);
  });
}
function renderDerived(c) {
  const r = c.report, box = $("#derived");
  if (!r) { box.innerHTML = ""; return; }
  const rows = [
    ["Reach from pivot", `${r.r_min_mm.toFixed(0)} to ${r.r_max_mm.toFixed(0)} mm`],
    ["Screw lead", `${r.lead_mm.toFixed(2)} mm/rev`],
    ["Pen step at full reach", `${r.pen_step_at_rmax_mm.toFixed(3)} mm`],
    ["Swing per step pair", `${r.theta_step_deg.toFixed(4)}°`],
    ["Reach per step pair", `${r.r_step_um.toFixed(2)} µm`],
    ["Steps per motor rev", `${r.steps_per_rev_motor}`],
  ];
  box.innerHTML = `<h2>What these settings give you</h2><dl>${rows.map(([a, b]) => `<dt>${a}</dt><dd>${b}</dd>`).join("")}</dl>` +
    `<ul class="warn">${(c.errors || []).map(e => `<li class="bad">${e}</li>`).join("")}${(c.warnings || []).map(e => `<li>${e}</li>`).join("")}</ul>`;
}
const checkSetup = debounce(guard(async () => {
  const c = await api("/api/config/check", S.dirty);
  renderDerived(c);
  if (c.report) { reachFromCfg(c); draw(); }
  $("#save").disabled = !!(c.errors && c.errors.length);
}), 250);
$("#save").addEventListener("click", guard(async () => {
  const c = await api("/api/config", { values: S.dirty, confirm: true });
  S.dirty = {}; buildSetup(c); reachFromCfg(c); toast("Settings saved. Home the machine again before drawing.");
  if (S.drawingLoaded) replan();
}));

$("#cfgExport").addEventListener("click", guard(async () => {
  const r = await fetch("/api/config/export", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(S.dirty) });
  if (!r.ok) { let m = ""; try { m = (await r.json()).detail; } catch (_) {} throw new Error(m || "Couldn't export the settings"); }
  const blob = await r.blob();
  const m = /filename="?([^";]+)/.exec(r.headers.get("content-disposition") || "");
  const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = m ? m[1] : "plotter-settings.yaml";
  document.body.append(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 2000);
  toast(Object.keys(S.dirty).length ? "Exported, including your unsaved changes." : "Settings exported.");
}));
$("#cfgImport").addEventListener("change", guard(async e => {
  const file = e.target.files[0]; e.target.value = ""; if (!file) return;
  if (file.size > 500000) throw new Error("That file is too large to be a settings file.");
  const r = await api("/api/config/import", { text: await file.text() });
  S.dirty = {}; buildSetup(S.cfg);
  let n = 0;
  for (const [k, v] of Object.entries(r.values)) {
    const f = S.cfg.fields.find(x => x.key === k), inp = $("#f_" + k.replace(/\./g, "_"));
    if (!f || !inp) continue;
    if (f.kind === "bool" ? !!v === !!f.value : Number(v) === Number(f.value)) continue;
    if (f.kind === "bool") inp.checked = !!v; else inp.value = v;
    S.dirty[k] = f.kind === "bool" ? !!v : v;
    const w = inp.closest(".fld"); w.classList.add("changed"); w.closest("details").open = true; n++;
  }
  checkSetup();
  const ign = r.ignored.length ? ` ${r.ignored.length} unknown entr${r.ignored.length > 1 ? "ies were" : "y was"} skipped.` : "";
  $("#saveNote").textContent = n ? "Settings loaded from file. Check the highlighted values, then save." : "";
  toast(n ? `Loaded ${n} changed setting${n > 1 ? "s" : ""}. Check them, then press Save.${ign}` : `That file matches your saved settings.${ign}`, false);
}));

// ------------------------------------------------------------------ drawing / plan
function layoutOpts() {
  return {
    fit: $("input[name=fit]:checked").value, scale: parseFloat($("#o_scale").value) || 1,
    rotate_deg: parseInt($("input[name=rot]:checked").value), mirror_x: $("#o_mirror").checked,
    margin_mm: parseFloat($("#o_margin").value) || 0, align: $("#o_align").value,
    offset_x_mm: parseFloat($("#o_ox").value) || 0, offset_y_mm: parseFloat($("#o_oy").value) || 0,
    exclude: S.excluded,
  };
}
let planSeq = 0;
const replan = guard(async () => {
  if (!S.drawingLoaded) return;
  const my = ++planSeq;
  const p = await api("/api/plan", layoutOpts());
  if (my !== planSeq) return;
  S.plan = p;
  S.plan.intendedP = p.intended.map(f => pathFromFlat(f));
  S.plan.drawnP = p.drawn.map(f => pathFromFlat(f));
  S.plan.pos = new Map(p.indices.map((o, j) => [o, j]));
  S.plan.bb = p.intended.map(f => {
    let x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9;
    for (let i = 0; i < f.length; i += 2) { x0 = Math.min(x0, f[i]); x1 = Math.max(x1, f[i]); y0 = Math.min(y0, f[i + 1]); y1 = Math.max(y1, f[i + 1]); }
    return [x0, y0, x1, y1];
  });
  S.sel = new Set([...S.sel].filter(o => S.plan.pos.has(o)));
  const st = p.stats;
  $("#summary").hidden = false;
  $("#s_strokes").textContent = st.n_strokes;
  $("#s_len").textContent = (st.draw_len_mm / 1000 >= 1 ? (st.draw_len_mm / 1000).toFixed(2) + " m" : st.draw_len_mm.toFixed(0) + " mm");
  $("#s_size").textContent = `${p.info.width_mm.toFixed(0)} × ${p.info.height_mm.toFixed(0)} mm`;
  $("#s_time").textContent = fmtTime(st.est_time_s);
  $("#planWarn").innerHTML = p.warnings.map(w => `<li>${w}</li>`).join("");
  renderStatus(S.status || await api("/api/status"));
  draw();
});
const replanSoon = debounce(replan, 300);
function pathFromFlat(f) {
  const p = new Path2D();
  for (let i = 0; i < f.length; i += 2) i ? p.lineTo(f[i], f[i + 1]) : p.moveTo(f[i], f[i + 1]);
  return p;
}
function onLoaded(info) {
  S.drawingLoaded = true; S.plan = null; S.trace = { n: 0, path: null, last: null };
  S.sel = new Set(); S.excluded = []; S.undo = [];
  $("#fileInfo").textContent = `${info.name}: ${info.strokes} strokes, ${info.width_mm.toFixed(0)} × ${info.height_mm.toFixed(0)} mm as drawn in the file`;
  $("#fileWarn").innerHTML = (info.warnings || []).map(w => `<li>${w}</li>`).join("");
  replan();
}
// ---- removing lines / the whole drawing
const busyNow = () => !!(S.status && ["running", "homing", "moving", "paused"].includes(S.status.state));
function renderLineTools() {
  $("#drawTools").hidden = !S.drawingLoaded;
  const n = S.sel.size, b = busyNow();
  $("#rmSel").textContent = n ? `Remove ${n} selected` : "Remove selected";
  $("#rmSel").disabled = b || !n;
  $("#undoRm").disabled = b || !S.undo.length;
  $("#restoreAll").disabled = b || !S.excluded.length;
  $("#rmDrawing").disabled = b;
  const r = S.excluded.length;
  $("#lineNote").textContent = (r ? `${r} line${r > 1 ? "s" : ""} removed from the job. ` : "") +
    (S.plan ? "Click lines on the sheet to select them (click again to deselect), then remove them." : "");
}
const removeSelected = guard(async () => {
  if (!S.sel.size || !S.plan || busyNow()) return;
  const rm = [...S.sel];
  if (S.excluded.length + rm.length >= S.plan.total) { toast("That would remove every line. Use Remove drawing instead.", true); return; }
  S.undo.push(rm); S.excluded.push(...rm); S.sel = new Set();
  renderLineTools(); await replan();
});
$("#rmSel").onclick = removeSelected;
$("#undoRm").onclick = guard(async () => {
  const last = S.undo.pop(); if (!last) return;
  S.excluded = S.excluded.filter(o => !last.includes(o)); renderLineTools(); await replan();
});
$("#restoreAll").onclick = guard(async () => { S.excluded = []; S.undo = []; renderLineTools(); await replan(); });
$("#rmDrawing").onclick = guard(async () => {
  renderStatus(await api("/api/drawing", undefined, "DELETE"));
  S.drawingLoaded = false; S.plan = null; planSeq++; S.sel = new Set(); S.excluded = []; S.undo = [];
  $("#fileInfo").textContent = "No drawing loaded. You can also drop a file onto the sheet.";
  $("#fileWarn").innerHTML = ""; $("#planWarn").innerHTML = ""; $("#summary").hidden = true;
  renderStatus(S.status); toast("Drawing removed.");
});
function pickStroke(wx, wy) {
  const p = S.plan; if (!p) return -1;
  const tol = 9 / S.view.s; let best = -1, bd = tol;
  for (let j = 0; j < p.intended.length; j++) {
    const b = p.bb[j];
    if (wx < b[0] - tol || wx > b[2] + tol || wy < b[1] - tol || wy > b[3] + tol) continue;
    const f = p.intended[j];
    for (let i = 0; i + 3 < f.length; i += 2) {
      const ax = f[i], ay = f[i + 1], dx = f[i + 2] - ax, dy = f[i + 3] - ay, L = dx * dx + dy * dy;
      const t = L ? Math.max(0, Math.min(1, ((wx - ax) * dx + (wy - ay) * dy) / L)) : 0;
      const d = Math.hypot(wx - (ax + t * dx), wy - (ay + t * dy));
      if (d < bd) { bd = d; best = j; }
    }
  }
  return best < 0 ? -1 : p.indices[best];
}
document.addEventListener("keydown", e => {
  if (/^(INPUT|SELECT|TEXTAREA)$/.test(document.activeElement.tagName)) return;
  if ($("#t-job").getAttribute("aria-selected") !== "true") return;
  if (e.key === "Delete" || e.key === "Backspace") { e.preventDefault(); removeSelected(); }
  else if (e.key === "Escape" && S.sel.size) { S.sel = new Set(); renderLineTools(); draw(); }
});
async function uploadFile(f) {
  const fd = new FormData(); fd.append("file", f);
  onLoaded(await api("/api/upload", fd));
}
$("#file").addEventListener("change", guard(async e => { if (e.target.files[0]) await uploadFile(e.target.files[0]); e.target.value = ""; }));
$("#example").addEventListener("change", guard(async e => {
  if (!e.target.value) return;
  onLoaded(await api("/api/examples/" + encodeURIComponent(e.target.value), {})); e.target.value = "";
}));
$$("#placement input, #placement select").forEach(el => el.addEventListener("input", () => {
  if (el.id === "o_speed") return;
  if (el.name === "fit") $("#o_scale").disabled = $("input[name=fit]:checked").value !== "scale";
  replanSoon();
}));
$("#o_speed").addEventListener("change", guard(async () => {
  const c = await api("/api/config", { values: { "motion.draw_speed_mm_s": $("#o_speed").value } });
  buildSetup(c); reachFromCfg(c); replan();
}));
// drag and drop
const stage = $("#stage");
["dragenter", "dragover"].forEach(ev => stage.addEventListener(ev, e => { e.preventDefault(); $("#drop").hidden = false; }));
["dragleave", "drop"].forEach(ev => stage.addEventListener(ev, e => { e.preventDefault(); $("#drop").hidden = true; }));
stage.addEventListener("drop", guard(async e => { const f = e.dataTransfer.files[0]; if (f) await uploadFile(f); }));

// ------------------------------------------------------------------ machine buttons
const post = (path, body) => guard(async () => renderStatus(await api(path, body || {})));
$("#home").onclick = post("/api/home");
$("#zero").onclick = guard(async () => {
  if (confirm("Treat the arm's current position as the zero position? Only do this if the arm is physically at its zero position.")) renderStatus(await api("/api/set_zero", {}));
});
$("#park").onclick = post("/api/park");
$("#motorsToggle").onclick = guard(async () => renderStatus(await api("/api/motors", { on: !S.status.motors_on })));
$("#penUp").onclick = post("/api/pen", { down: false });
$("#penDown").onclick = post("/api/pen", { down: true });
$("#start").onclick = post("/api/job/start");
$("#pause").onclick = post("/api/job/pause");
$("#resume").onclick = post("/api/job/resume");
$("#stop").onclick = post("/api/job/stop");
$("#estop").onclick = post("/api/estop");
$$(".jog").forEach(row => $$("button", row).forEach(b => b.onclick = guard(async () =>
  renderStatus(await api("/api/jog", { kind: row.dataset.kind, amount: parseFloat(b.dataset.a) })))));
$$("[data-m]").forEach(b => b.onclick = guard(async () =>
  renderStatus(await api("/api/jog", { kind: "motor", motor: b.dataset.m, steps: parseInt(b.dataset.s) }))));
$("#goBtn").onclick = guard(async () =>
  renderStatus(await api("/api/jog", { kind: "xy", x: parseFloat($("#goX").value), y: parseFloat($("#goY").value) })));

// ------------------------------------------------------------------ canvas
const cv = $("#cv"), ctx = cv.getContext("2d");
let dpr = 1, dirty = false;
const hatch = (() => {
  const c = document.createElement("canvas"); c.width = c.height = 10;
  const g = c.getContext("2d"); g.strokeStyle = "#aeb5bb"; g.lineWidth = 1;
  g.beginPath(); g.moveTo(-2, 12); g.lineTo(12, -2); g.moveTo(-2, 2); g.lineTo(2, -2); g.moveTo(8, 12); g.lineTo(12, 8); g.stroke();
  return c;
})();
function resize() {
  const r = cv.getBoundingClientRect(); dpr = window.devicePixelRatio || 1;
  cv.width = Math.max(1, Math.round(r.width * dpr)); cv.height = Math.max(1, Math.round(r.height * dpr));
  if (!S.view.fitted) fitView(); draw();
}
function worldBounds() {
  const R = S.reach; if (!R) return [-20, -20, 300, 300];
  const pts = [[0, 0], [R.paper.ox, R.paper.oy], [R.paper.ox + R.paper.w, R.paper.oy + R.paper.h]];
  for (let t = R.tmin; t <= R.tmax; t += 2) { pts.push(jointXY(t, R.travel)); pts.push(jointXY(t, 0)); }
  const xs = pts.map(p => p[0]), ys = pts.map(p => p[1]);
  return [Math.min(...xs), Math.min(...ys), Math.max(...xs), Math.max(...ys)];
}
function fitView() {
  const [x0, y0, x1, y1] = worldBounds(), w = cv.width / dpr, h = cv.height / dpr, pad = 34;
  const s = Math.min((w - 2 * pad) / Math.max(x1 - x0, 1), (h - 2 * pad) / Math.max(y1 - y0, 1));
  S.view = { s, ox: pad - x0 * s + (w - 2 * pad - (x1 - x0) * s) / 2, oy: h - pad + y0 * s - (h - 2 * pad - (y1 - y0) * s) / 2, fitted: true };
  draw();
}
const toScreen = (x, y) => [S.view.ox + x * S.view.s, S.view.oy - y * S.view.s];
const toWorld = (px, py) => [(px - S.view.ox) / S.view.s, (S.view.oy - py) / S.view.s];
function draw() { if (!dirty) { dirty = true; requestAnimationFrame(render); } }
function reachPath() {
  const R = S.reach, p = new Path2D(); let first = true;
  const add = (x, y) => { if (first) { p.moveTo(x, y); first = false; } else p.lineTo(x, y); };
  for (let t = R.tmin; t <= R.tmax + 1e-6; t += 1) add(...jointXY(t, R.travel));
  add(...jointXY(R.tmax, R.travel));
  for (let q = R.travel; q >= 0; q -= R.travel / 20) add(...jointXY(R.tmax, q));
  for (let t = R.tmax; t >= R.tmin - 1e-6; t -= 1) add(...jointXY(t, 0));
  for (let q = 0; q <= R.travel; q += R.travel / 20) add(...jointXY(R.tmin, q));
  p.closePath(); return p;
}
function render() {
  dirty = false;
  const W = cv.width, H = cv.height, V = S.view;
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.fillStyle = "#dde1e3"; ctx.fillRect(0, 0, W, H);
  const R = S.reach; if (!R) return;
  const k = dpr * V.s;
  const world = () => ctx.setTransform(k, 0, 0, -k, V.ox * dpr, V.oy * dpr);
  const px = n => n / k;                        // pixel width in world units
  const screen = () => ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  const pat = ctx.createPattern(hatch, "repeat");
  // everything outside the reachable sector is hatched
  screen(); ctx.fillStyle = pat; ctx.fillRect(0, 0, W / dpr, H / dpr);
  const rp = reachPath();
  world(); ctx.fillStyle = "#f1f2ee"; ctx.fill(rp);
  ctx.strokeStyle = "#7d858b"; ctx.lineWidth = px(1); ctx.stroke(rp);
  // paper
  const P = R.paper;
  ctx.fillStyle = "#fdfdfb"; ctx.fillRect(P.ox, P.oy, P.w, P.h);
  // unreachable part of the paper gets a stronger hatch
  ctx.save(); ctx.beginPath(); ctx.rect(P.ox, P.oy, P.w, P.h); ctx.clip();
  const big = new Path2D(); big.rect(-1e4, -1e4, 2e4, 2e4); big.addPath(rp);
  screen(); ctx.fillStyle = pat;
  const inv = new Path2D(); inv.addPath(big, new DOMMatrix([V.s, 0, 0, -V.s, V.ox, V.oy]));
  ctx.fill(inv, "evenodd"); ctx.restore();
  // grid on paper
  world(); ctx.save(); ctx.beginPath(); ctx.rect(P.ox, P.oy, P.w, P.h); ctx.clip(); ctx.clip(rp);
  ctx.lineWidth = px(1);
  for (let x = Math.ceil(P.ox / 10) * 10; x <= P.ox + P.w; x += 10) { ctx.strokeStyle = x % 50 ? "#0000000d" : "#00000022"; ctx.beginPath(); ctx.moveTo(x, P.oy); ctx.lineTo(x, P.oy + P.h); ctx.stroke(); }
  for (let y = Math.ceil(P.oy / 10) * 10; y <= P.oy + P.h; y += 10) { ctx.strokeStyle = y % 50 ? "#0000000d" : "#00000022"; ctx.beginPath(); ctx.moveTo(P.ox, y); ctx.lineTo(P.ox + P.w, y); ctx.stroke(); }
  ctx.restore();
  ctx.strokeStyle = "#1f2428"; ctx.lineWidth = px(1.4); ctx.strokeRect(P.ox, P.oy, P.w, P.h);
  // drawing
  const plan = S.plan;
  if (plan) {
    ctx.lineJoin = "round"; ctx.lineCap = "round";
    if ($("#showGhost").checked) { ctx.strokeStyle = "#8a9299"; ctx.lineWidth = px(0.8); ctx.setLineDash([px(4), px(3)]); plan.intendedP.forEach(p => ctx.stroke(p)); ctx.setLineDash([]); }
    if ($("#showTravel").checked) {
      ctx.strokeStyle = "#626a71"; ctx.lineWidth = px(0.7); ctx.setLineDash([px(1), px(4)]);
      ctx.beginPath(); plan.travels.forEach(t => { ctx.moveTo(t[0], t[1]); ctx.lineTo(t[2], t[3]); }); ctx.stroke(); ctx.setLineDash([]);
    }
    ctx.strokeStyle = "#1d3bb0"; ctx.globalAlpha = S.trace.path ? .35 : 1; ctx.lineWidth = px(1.3);
    plan.drawnP.forEach(p => ctx.stroke(p)); ctx.globalAlpha = 1;
    if (S.sel.size) {
      ctx.strokeStyle = "#c2321e"; ctx.lineWidth = px(2.8); ctx.setLineDash([]);
      S.sel.forEach(o => { const j = plan.pos.get(o); if (j !== undefined) ctx.stroke(plan.intendedP[j]); });
    }
  }
  if (S.trace.path) { ctx.strokeStyle = "#0f2278"; ctx.lineWidth = px(2); ctx.lineJoin = "round"; ctx.lineCap = "round"; ctx.stroke(S.trace.path); }
  // pivot and arm
  const s = S.status;
  ctx.fillStyle = "#1f2428"; ctx.beginPath(); ctx.arc(0, 0, px(6), 0, 7); ctx.fill();
  if (s && s.homed) {
    const a = R.a0 + s.q_mm, th = s.theta_deg * Math.PI / 180, e = R.e;
    const ex = a * Math.cos(th), ey = a * Math.sin(th);
    ctx.strokeStyle = "#1f2428"; ctx.lineWidth = px(3); ctx.lineCap = "round"; ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(ex, ey);
    if (e) ctx.lineTo(s.x, s.y); ctx.stroke();
    ctx.lineWidth = px(1.2); ctx.strokeStyle = "#ffffff"; ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(ex, ey); ctx.stroke();
    ctx.beginPath(); ctx.arc(s.x, s.y, px(6), 0, 7);
    if (s.pen_down) { ctx.fillStyle = "#1d3bb0"; ctx.fill(); ctx.strokeStyle = "#fff"; ctx.lineWidth = px(1.5); ctx.stroke(); }
    else { ctx.fillStyle = "#fff"; ctx.fill(); ctx.strokeStyle = "#1f2428"; ctx.lineWidth = px(2); ctx.stroke(); }
  }
  if (S.target) {
    const [tx, ty] = S.target; ctx.strokeStyle = "#c2321e"; ctx.lineWidth = px(1.5);
    const r = px(9); ctx.beginPath(); ctx.moveTo(tx - r, ty); ctx.lineTo(tx + r, ty); ctx.moveTo(tx, ty - r); ctx.lineTo(tx, ty + r); ctx.stroke();
  }
  // labels (screen space)
  screen(); ctx.fillStyle = "#626a71"; ctx.font = "12px Instrument Sans, system-ui, sans-serif"; ctx.textBaseline = "top";
  let [sx, sy] = toScreen(0, 0); ctx.fillText("pivot", sx + 9, sy + 6);
  [sx, sy] = toScreen(...jointXY(R.tmax, R.travel)); ctx.fillText(`${R.rmax.toFixed(0)} mm`, sx + 6, sy - 4);
  [sx, sy] = toScreen(P.ox, P.oy); ctx.fillText(`paper ${P.w.toFixed(0)} × ${P.h.toFixed(0)} mm`, Math.max(sx, 8) + 6, Math.min(sy, cv.height / dpr - 18) + 4 - 0);
}

// pan / zoom / pick
let drag = null;
cv.addEventListener("pointerdown", e => { cv.setPointerCapture(e.pointerId); drag = { x: e.clientX, y: e.clientY, ox: S.view.ox, oy: S.view.oy, moved: false }; });
cv.addEventListener("pointermove", e => {
  const r = cv.getBoundingClientRect(), [wx, wy] = toWorld(e.clientX - r.left, e.clientY - r.top);
  $("#cursor").textContent = `x ${wx.toFixed(1)}  y ${wy.toFixed(1)} mm`;
  if (drag) {
    const dx = e.clientX - drag.x, dy = e.clientY - drag.y;
    if (Math.abs(dx) + Math.abs(dy) > 4) drag.moved = true;
    if (drag.moved) { S.view.ox = drag.ox + dx; S.view.oy = drag.oy + dy; draw(); }
  }
});
cv.addEventListener("pointerup", e => {
  if (drag && !drag.moved) {
    const r = cv.getBoundingClientRect(), [wx, wy] = toWorld(e.clientX - r.left, e.clientY - r.top);
    if ($("#t-job").getAttribute("aria-selected") === "true") {
      if (S.plan && !busyNow()) {
        const o = pickStroke(wx, wy);
        if (o < 0) S.sel = new Set(); else if (S.sel.has(o)) S.sel.delete(o); else S.sel.add(o);
        renderLineTools(); draw();
      }
    } else {
      S.target = [wx, wy]; $("#goX").value = wx.toFixed(1); $("#goY").value = wy.toFixed(1); draw();
    }
  }
  drag = null;
});
cv.addEventListener("wheel", e => {
  e.preventDefault();
  const r = cv.getBoundingClientRect(), mx = e.clientX - r.left, my = e.clientY - r.top, [wx, wy] = toWorld(mx, my);
  const f = Math.exp(-e.deltaY * 0.0015); S.view.s *= f; S.view.ox = mx - wx * S.view.s; S.view.oy = my + wy * S.view.s; draw();
}, { passive: false });
$("#fitView").onclick = fitView;
["showGhost", "showTravel"].forEach(id => $("#" + id).addEventListener("change", draw));
new ResizeObserver(() => { S.view.fitted = false; resize(); }).observe(cv);

// ------------------------------------------------------------------ boot
(async function boot() {
  try {
    const [c, ex] = await Promise.all([api("/api/config"), api("/api/examples")]);
    $("#example").innerHTML = `<option value="">Try an example</option>` + ex.map(n => `<option>${n}</option>`).join("");
    buildSetup(c); reachFromCfg(c);
    if (!c.confirmed) selectTab("setup");
  } catch (e) { toast(e.message, true); }
  resize(); fitView();
  pollStatus(); pollLogs();
})();
