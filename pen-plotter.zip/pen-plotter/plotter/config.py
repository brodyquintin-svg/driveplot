"""Configuration: one flat, schema-driven settings store.

Every tunable lives in SCHEMA so the web UI can render the settings form
automatically and the server can validate what comes back.  The on-disk
format is nested YAML (``gears: {a_drive_pd_mm: 16, ...}``).
"""
from __future__ import annotations

import copy
import os
from dataclasses import dataclass
from typing import Any

import yaml


@dataclass(frozen=True)
class Field:
    key: str            # dotted name, e.g. "gears.a_drive_pd_mm"
    label: str
    unit: str
    kind: str           # float | int | bool | choice
    default: Any
    group: str
    help: str = ""
    choices: tuple = ()


F = Field
SCHEMA: list[Field] = [
    # ---- Gear train -------------------------------------------------------
    F("gears.a_drive_pd_mm", "Motor A gear (on motor shaft)", "mm", "float", 16.0, "Gear trains",
      "Pitch diameter of the gear on motor A's shaft. Only the ratio matters. "
      "If the motor drives the bevel gear directly, set driven = drive."),
    F("gears.a_driven_pd_mm", "Gear driven by motor A", "mm", "float", 48.0, "Gear trains",
      "Pitch diameter of the gear motor A drives (it turns the side bevel gear)."),
    F("gears.b_drive_pd_mm", "Motor B gear (on motor shaft)", "mm", "float", 16.0, "Gear trains", ""),
    F("gears.b_driven_pd_mm", "Gear driven by motor B", "mm", "float", 48.0, "Gear trains", ""),
    # ---- Bevels -----------------------------------------------------------
    F("bevel.side_pd_mm", "Side bevel gear (x2, identical)", "mm", "float", 40.0, "Bevel differential",
      "Pitch diameter of the two side bevel gears (one per motor)."),
    F("bevel.pinion_pd_mm", "Pinion bevel gear", "mm", "float", 20.0, "Bevel differential",
      "Pitch diameter of the pinion that rides between the side gears and turns the lead screw."),
    # ---- Lead screw -------------------------------------------------------
    F("screw.thread_pitch_mm", "Thread pitch", "mm", "float", 2.0, "Lead screw",
      "Distance between adjacent thread crests (T8x2 -> 2)."),
    F("screw.starts", "Thread starts", "", "int", 4, "Lead screw",
      "Number of thread starts. Lead = pitch x starts (T8x2 4-start -> 8 mm/rev)."),
    F("screw.length_mm", "Lead screw length", "mm", "float", 200.0, "Lead screw", "Total rod length."),
    F("screw.unusable_mm", "Unusable length", "mm", "float", 30.0, "Lead screw",
      "Length you can't travel (nut length, end blocks, pen holder). Travel = length - unusable."),
    F("screw.gear_ratio", "Screw turns per pinion turn", "", "float", 1.0, "Lead screw",
      "1.0 if the pinion shaft is the screw. Set it if a gear sits between pinion and screw."),
    F("screw.r_home_mm", "Pen distance from pivot at home", "mm", "float", 60.0, "Lead screw",
      "Distance from the pivot axis to the pen tip, measured along the screw, when the r-home switch triggers (fully retracted)."),
    F("screw.offset_mm", "Screw axis sideways offset", "mm", "float", 0.0, "Lead screw",
      "Perpendicular distance between the screw axis and the pivot axis. 0 if the screw points through the pivot."),
    # ---- Motors -----------------------------------------------------------
    F("motors.full_steps_per_rev", "Full steps per revolution", "", "int", 200, "Steppers & drivers",
      "42HBR8021Y-24B-10 (1.8 deg) = 200."),
    F("motors.microsteps", "Microstep setting", "", "choice", 16, "Steppers & drivers",
      "Must match your driver's MS1/MS2/MS3 jumpers or config.", (1, 2, 4, 8, 16, 32, 64, 128, 256)),
    F("motors.a_invert", "Invert motor A direction", "", "bool", False, "Steppers & drivers",
      "Flip if jog direction is wrong (see README bring-up)."),
    F("motors.b_invert", "Invert motor B direction", "", "bool", False, "Steppers & drivers", ""),
    F("motors.enable_active_low", "Driver ENABLE is active-low", "", "bool", True, "Steppers & drivers",
      "True for A4988, DRV8825, TMC2209."),
    F("motors.idle_disable_s", "Disable motors after idle", "s", "float", 300.0, "Steppers & drivers",
      "Cuts holding current (and heat) when nothing has moved for this long. 0 = never. Position stays valid unless you move the arm by hand."),
    F("kin.theta_sign", "Swing direction sign", "", "choice", 1, "Steppers & drivers",
      "+1 or -1. Flip if 'Jog +theta' swings the arm clockwise.", (1, -1)),
    F("kin.r_sign", "Extension direction sign", "", "choice", 1, "Steppers & drivers",
      "+1 or -1. Flip if 'Jog +r' retracts the pen.", (1, -1)),
    # ---- Pins -------------------------------------------------------------
    F("pins.a_step", "Motor A STEP", "GPIO (BCM)", "int", 17, "Pi pins", ""),
    F("pins.a_dir", "Motor A DIR", "GPIO (BCM)", "int", 27, "Pi pins", ""),
    F("pins.a_en", "Motor A ENABLE", "GPIO (BCM)", "int", 22, "Pi pins", ""),
    F("pins.b_step", "Motor B STEP", "GPIO (BCM)", "int", 23, "Pi pins", ""),
    F("pins.b_dir", "Motor B DIR", "GPIO (BCM)", "int", 24, "Pi pins", ""),
    F("pins.b_en", "Motor B ENABLE", "GPIO (BCM)", "int", 25, "Pi pins", ""),
    F("pins.servo", "Pen servo signal", "GPIO (BCM)", "int", 26, "Pi pins",
      "Any GPIO. Avoid 12, 13, 18, 19 (pigpio uses PWM/PCM hardware for timing)."),
    F("pins.theta_switch", "Theta home switch", "GPIO (BCM)", "int", 5, "Pi pins", ""),
    F("pins.r_switch", "Radial home switch", "GPIO (BCM)", "int", 6, "Pi pins", ""),
    F("pins.switch_active_low", "Switches pull pin to GND when pressed", "", "bool", True, "Pi pins",
      "Normally-open switch between pin and GND using the Pi's internal pull-up -> True."),
    # ---- Homing / limits --------------------------------------------------
    F("home.theta_deg", "Arm angle at theta switch", "deg", "float", 0.0, "Homing & limits",
      "Angle of the arm, measured CCW from paper's +X axis (bottom edge), when the theta switch triggers."),
    F("home.theta_dir", "Direction toward theta switch", "", "choice", -1, "Homing & limits",
      "-1 = switch is reached by decreasing theta, +1 = by increasing.", (-1, 1)),
    F("home.r_dir", "Direction toward r switch", "", "choice", -1, "Homing & limits",
      "-1 = switch is reached by retracting (decreasing r), +1 = by extending.", (-1, 1)),
    F("home.fast_hz", "Homing seek speed", "steps/s", "float", 1500.0, "Homing & limits", ""),
    F("home.slow_hz", "Homing final approach speed", "steps/s", "float", 250.0, "Homing & limits", ""),
    F("home.backoff_deg", "Theta back-off after switch", "deg", "float", 3.0, "Homing & limits", ""),
    F("home.backoff_mm", "Radial back-off after switch", "mm", "float", 2.0, "Homing & limits", ""),
    F("home.max_theta_deg", "Max theta travel while homing", "deg", "float", 200.0, "Homing & limits",
      "Homing aborts if the switch isn't found within this."),
    F("home.max_r_mm", "Max radial travel while homing", "mm", "float", 400.0, "Homing & limits", ""),
    F("limits.theta_min_deg", "Soft limit theta min", "deg", "float", -2.0, "Homing & limits", ""),
    F("limits.theta_max_deg", "Soft limit theta max", "deg", "float", 92.0, "Homing & limits", ""),
    # ---- Paper ------------------------------------------------------------
    F("paper.width_mm", "Paper width (X)", "mm", "float", 210.0, "Paper", ""),
    F("paper.height_mm", "Paper height (Y)", "mm", "float", 297.0, "Paper", ""),
    F("paper.origin_x_mm", "Paper corner X from pivot", "mm", "float", 0.0, "Paper",
      "Where the paper's bottom-left corner sits relative to the pivot axis. 0,0 = pivot exactly on the corner."),
    F("paper.origin_y_mm", "Paper corner Y from pivot", "mm", "float", 0.0, "Paper", ""),
    # ---- Motion -----------------------------------------------------------
    F("motion.draw_speed_mm_s", "Drawing speed", "mm/s", "float", 40.0, "Motion", ""),
    F("motion.travel_speed_mm_s", "Pen-up travel speed", "mm/s", "float", 120.0, "Motion", ""),
    F("motion.accel_mm_s2", "Acceleration", "mm/s^2", "float", 400.0, "Motion", ""),
    F("motion.max_step_rate_hz", "Max step rate per motor", "steps/s", "float", 15000.0, "Motion",
      "Hard cap. Lower it if the motors stall; raise it for TMC2209 with enough supply voltage."),
    F("motion.step_accel_hz_s", "Step-rate acceleration", "steps/s^2", "float", 120000.0, "Motion",
      "Caps how fast each motor's step rate may ramp. Lower it if motors stall on starts."),
    F("motion.jerk_hz", "Instant step-rate change allowed", "steps/s", "float", 1000.0, "Motion",
      "How abruptly a motor's step rate may change (start speed, direction reversals, sharp corners)."),
    F("motion.junction_dev_mm", "Corner deviation", "mm", "float", 0.05, "Motion",
      "Larger = faster through corners but rounder corners."),
    F("motion.chord_tol_mm", "Curve tolerance", "mm", "float", 0.02, "Motion",
      "Max deviation from the true path when straight lines are cut into polar moves."),
    F("motion.max_segment_mm", "Max segment length", "mm", "float", 1.0, "Motion", ""),
    F("motion.join_tol_mm", "Join strokes closer than", "mm", "float", 0.15, "Motion",
      "Strokes whose ends are this close are drawn without lifting the pen."),
    F("motion.backlash_a_steps", "Backlash motor A", "steps", "int", 0, "Motion",
      "Extra steps inserted when motor A reverses."),
    F("motion.backlash_b_steps", "Backlash motor B", "steps", "int", 0, "Motion", ""),
    F("motion.backlash_rate_hz", "Backlash take-up rate", "steps/s", "float", 1500.0, "Motion", ""),
    # ---- Pen --------------------------------------------------------------
    F("pen.up_us", "Servo pulse, pen up", "us", "int", 1700, "Pen servo", ""),
    F("pen.down_us", "Servo pulse, pen down", "us", "int", 1300, "Pen servo", ""),
    F("pen.settle_s", "Pen settle time", "s", "float", 0.25, "Pen servo",
      "Pause after each pen up/down so the servo finishes moving."),
    # ---- Server -----------------------------------------------------------
    F("server.port", "HTTPS port", "", "int", 8443, "Server", "Restart required."),
]

BY_KEY = {f.key: f for f in SCHEMA}
META_KEY = "meta.confirmed"


class ConfigError(ValueError):
    pass


def _coerce(f: Field, v: Any) -> Any:
    try:
        if f.kind == "bool":
            if isinstance(v, str):
                return v.strip().lower() in ("1", "true", "yes", "on")
            return bool(v)
        if f.kind == "int":
            return int(round(float(v)))
        if f.kind == "float":
            return float(v)
        if f.kind == "choice":
            v = float(v)
            for c in f.choices:
                if float(c) == v:
                    return c
            raise ValueError(f"{v} not in {f.choices}")
    except (TypeError, ValueError) as e:
        raise ConfigError(f"{f.label}: invalid value {v!r} ({e})")
    return v


class Config:
    def __init__(self, values: dict[str, Any] | None = None, path: str | None = None):
        self.path = path
        self.v: dict[str, Any] = {f.key: copy.copy(f.default) for f in SCHEMA}
        self.v[META_KEY] = False
        if values:
            self.update(values)

    # -- access -----------------------------------------------------------
    def __getitem__(self, key: str) -> Any:
        return self.v[key]

    @property
    def confirmed(self) -> bool:
        return bool(self.v[META_KEY])

    # -- mutation ---------------------------------------------------------
    def update(self, values: dict[str, Any]) -> None:
        new = dict(self.v)
        for k, val in values.items():
            if k == META_KEY:
                new[k] = bool(val)
            elif k in BY_KEY:
                new[k] = _coerce(BY_KEY[k], val)
            # unknown keys ignored so old config files keep loading
        errs, _ = validate_values(new)
        if errs:
            raise ConfigError("; ".join(errs))
        self.v = new

    # -- (de)serialisation ---------------------------------------------------
    def to_nested(self) -> dict:
        out: dict = {}
        for k, val in self.v.items():
            sec, name = k.split(".", 1)
            out.setdefault(sec, {})[name] = val
        return out

    @classmethod
    def from_nested(cls, d: dict, path: str | None = None) -> "Config":
        flat = {}
        for sec, body in (d or {}).items():
            if isinstance(body, dict):
                for name, val in body.items():
                    flat[f"{sec}.{name}"] = val
        return cls(flat, path)

    @classmethod
    def load(cls, path: str) -> "Config":
        if not os.path.exists(path):
            return cls(path=path)
        with open(path) as fh:
            return cls.from_nested(yaml.safe_load(fh) or {}, path)

    def save(self, path: str | None = None) -> None:
        path = path or self.path
        if not path:
            raise ConfigError("no config path")
        tmp = path + ".tmp"
        with open(tmp, "w") as fh:
            fh.write("# Pen plotter settings (edited by the web UI)\n")
            yaml.safe_dump(self.to_nested(), fh, sort_keys=False)
        os.replace(tmp, path)

    def schema_json(self) -> list[dict]:
        return [dict(key=f.key, label=f.label, unit=f.unit, kind=f.kind, group=f.group,
                     help=f.help, choices=list(f.choices), value=self.v[f.key]) for f in SCHEMA]


def validate_values(v: dict[str, Any]) -> tuple[list[str], list[str]]:
    """Returns (errors, warnings)."""
    errs, warns = [], []
    pos = ["gears.a_drive_pd_mm", "gears.a_driven_pd_mm", "gears.b_drive_pd_mm", "gears.b_driven_pd_mm",
           "bevel.side_pd_mm", "bevel.pinion_pd_mm", "screw.thread_pitch_mm", "screw.length_mm",
           "screw.gear_ratio", "motors.full_steps_per_rev", "paper.width_mm", "paper.height_mm",
           "motion.draw_speed_mm_s", "motion.travel_speed_mm_s", "motion.accel_mm_s2",
           "motion.max_step_rate_hz", "motion.step_accel_hz_s", "motion.jerk_hz", "motion.junction_dev_mm",
           "motion.chord_tol_mm", "motion.max_segment_mm", "home.fast_hz", "home.slow_hz",
           "motion.backlash_rate_hz"]
    for k in pos:
        if not v[k] > 0:
            errs.append(f"{BY_KEY[k].label} must be > 0")
    if v["screw.starts"] < 1:
        errs.append("Thread starts must be >= 1")
    if v["screw.length_mm"] - v["screw.unusable_mm"] <= 0:
        errs.append("Screw length must exceed unusable length")
    if v["limits.theta_min_deg"] >= v["limits.theta_max_deg"]:
        errs.append("Theta min must be below theta max")
    if v["motion.max_segment_mm"] < 0.05:
        errs.append("Max segment length must be >= 0.05 mm")
    if abs(v["screw.offset_mm"]) >= v["screw.r_home_mm"] and v["screw.r_home_mm"] > 0:
        errs.append("Screw offset must be smaller than the home distance")
    pins = [k for k in v if k.startswith("pins.") and k != "pins.switch_active_low"]
    used: dict[int, str] = {}
    for k in pins:
        p = v[k]
        if not 0 <= p <= 27:
            errs.append(f"{BY_KEY[k].label}: GPIO must be 0-27")
        elif p in used:
            errs.append(f"GPIO {p} used by both '{used[p]}' and '{BY_KEY[k].label}'")
        else:
            used[p] = BY_KEY[k].label
    if v["pins.servo"] in (12, 13, 18, 19):
        warns.append("Servo on a hardware-PWM pin (12/13/18/19) can conflict with pigpio timing.")
    if v["motion.max_step_rate_hz"] > 30000:
        warns.append("Step rates above ~30 kHz are unreliable with pigpio on a Pi 4.")
    if abs(v["gears.a_driven_pd_mm"] / v["gears.a_drive_pd_mm"] - v["gears.b_driven_pd_mm"] / v["gears.b_drive_pd_mm"]) > 1e-3 * max(1, v["gears.a_driven_pd_mm"] / v["gears.a_drive_pd_mm"]):
        warns.append("Motor A and B gear ratios differ; the math handles it but check your numbers.")
    return errs, warns


def validate(cfg: Config) -> tuple[list[str], list[str]]:
    errs, warns = validate_values(cfg.v)
    if not cfg.confirmed:
        warns.append("Settings are still the placeholder defaults. Review them and press Save before running a job on the real machine.")
    return errs, warns
