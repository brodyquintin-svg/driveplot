"""Drawing input: SVG and DXF -> list of polylines in millimetres (Y up)."""
from __future__ import annotations

import math
import os
from dataclasses import dataclass, field

import numpy as np

PX_TO_MM = 25.4 / 96.0


@dataclass
class Drawing:
    strokes: list            # list[np.ndarray (N,2)] in mm, Y up
    warnings: list = field(default_factory=list)
    source: str = ""

    def bbox(self):
        if not self.strokes:
            return (0.0, 0.0, 0.0, 0.0)
        allp = np.vstack(self.strokes)
        return (*allp.min(axis=0), *allp.max(axis=0))


def _clean(pts) -> np.ndarray | None:
    a = np.asarray(pts, dtype=float).reshape(-1, 2)
    if len(a) < 2:
        return None
    keep = np.ones(len(a), bool)
    keep[1:] = np.hypot(*(a[1:] - a[:-1]).T) > 1e-6
    a = a[keep]
    return a if len(a) >= 2 else None


# ---------------------------------------------------------------------------
# SVG
# ---------------------------------------------------------------------------
def load_svg(path: str) -> Drawing:
    from svgelements import (SVG, Shape, Path, Move, Close, Line, QuadraticBezier,
                             CubicBezier, Arc, Text, Image)
    svg = SVG.parse(path, reify=True, ppi=96.0)
    strokes, warns = [], []
    skipped_text = skipped_img = 0
    step_px = 0.2 / PX_TO_MM
    for el in svg.elements():
        if isinstance(el, Text):
            skipped_text += 1
            continue
        if isinstance(el, Image):
            skipped_img += 1
            continue
        if not isinstance(el, Shape):
            continue
        vals = getattr(el, "values", {}) or {}
        if str(vals.get("display", "")).strip() == "none" or str(vals.get("visibility", "")).strip() == "hidden":
            continue
        try:
            p = el if isinstance(el, Path) else Path(el)
            p = abs(p)  # absolute coordinates
        except Exception:
            continue
        cur: list = []
        start = None
        for seg in p:
            if isinstance(seg, Move):
                if len(cur) >= 2:
                    strokes.append(cur)
                start = (seg.end.x, seg.end.y)
                cur = [start]
            elif isinstance(seg, Close):
                if cur and start is not None:
                    cur.append(start)
                if len(cur) >= 2:
                    strokes.append(cur)
                cur = [start] if start is not None else []
            elif isinstance(seg, Line):
                if not cur and seg.start is not None:
                    cur = [(seg.start.x, seg.start.y)]
                    start = start or cur[0]
                cur.append((seg.end.x, seg.end.y))
            elif isinstance(seg, (QuadraticBezier, CubicBezier, Arc)):
                if not cur and seg.start is not None:
                    cur = [(seg.start.x, seg.start.y)]
                    start = start or cur[0]
                try:
                    length = float(seg.length(error=1e-3))
                except Exception:
                    length = 10 * step_px
                n = max(8, int(math.ceil(length / step_px)))
                for t in np.linspace(0, 1, n + 1)[1:]:
                    pt = seg.point(float(t))
                    cur.append((pt.x, pt.y))
        if len(cur) >= 2:
            strokes.append(cur)
    out = []
    for s in strokes:
        a = _clean(s)
        if a is not None:
            a = a * PX_TO_MM
            a[:, 1] *= -1.0          # SVG is Y-down
            out.append(a)
    if skipped_text:
        warns.append(f"{skipped_text} <text> element(s) skipped. Convert text to paths first (Inkscape: Path > Object to Path).")
    if skipped_img:
        warns.append(f"{skipped_img} embedded image(s) skipped.")
    return Drawing(out, warns, "svg")


# ---------------------------------------------------------------------------
# DXF
# ---------------------------------------------------------------------------
def load_dxf(path: str) -> Drawing:
    import ezdxf
    from ezdxf import units as ezunits
    from ezdxf import path as ezpath

    doc = ezdxf.readfile(path)
    warns = []
    try:
        code = doc.units
    except Exception:
        code = 0
    if code in (0, None):
        factor = 1.0
        warns.append("DXF has no unit setting; assuming millimetres.")
    else:
        factor = ezunits.conversion_factor(code, ezunits.MM)
    dist = 0.02 / factor if factor else 0.02
    strokes, skipped = [], {}

    def handle(e, depth=0):
        t = e.dxftype()
        if t in ("TEXT", "MTEXT", "ATTRIB", "ATTDEF"):
            skipped[t] = skipped.get(t, 0) + 1
            return
        if t in ("INSERT", "DIMENSION", "LEADER", "MLEADER", "MULTILEADER") and depth < 6:
            try:
                for v in e.virtual_entities():
                    handle(v, depth + 1)
                return
            except Exception:
                skipped[t] = skipped.get(t, 0) + 1
                return
        if t == "POINT":
            return
        try:
            pth = ezpath.make_path(e)
        except Exception:
            skipped[t] = skipped.get(t, 0) + 1
            return
        for sub in pth.sub_paths():
            pts = [(v.x, v.y) for v in sub.flattening(dist)]
            a = _clean(pts)
            if a is not None:
                strokes.append(a * factor)

    for e in doc.modelspace():
        layer_obj = doc.layers.get(e.dxf.layer) if e.dxf.hasattr("layer") else None
        if layer_obj is not None and (not layer_obj.is_on() or layer_obj.is_frozen()):
            continue
        handle(e)
    for t, n in skipped.items():
        warns.append(f"{n} {t} entit{'y' if n == 1 else 'ies'} skipped (unsupported; convert text to outlines / explode).")
    return Drawing(strokes, warns, "dxf")


def load_drawing(path: str) -> Drawing:
    ext = os.path.splitext(path)[1].lower()
    if ext == ".svg":
        d = load_svg(path)
    elif ext == ".dxf":
        d = load_dxf(path)
    else:
        raise ValueError(f"Unsupported file type '{ext}'. Use .svg or .dxf")
    if not d.strokes:
        raise ValueError("No drawable lines found in the file.")
    return d
