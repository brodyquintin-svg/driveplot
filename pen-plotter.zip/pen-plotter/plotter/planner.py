"""Path planning: strokes (workspace mm) -> timed motor step events.

Pipeline
    clip to reachable annulus -> order / join strokes -> subdivide so that
    motor-linear interpolation stays within tolerance of the true straight
    line -> velocity profile (accel, junction, step-rate limits) -> step
    event times -> 10 us "ticks" that a driver can play out.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field

import numpy as np

from .config import Config
from .kinematics import Kinematics

TICK_US = 10            # event quantisation; STEP pulse is shorter than this
EMPTY_F = np.zeros(0)
EMPTY_I = np.zeros(0, np.int8)


# ===========================================================================
# Stroke preparation
# ===========================================================================
def densify(P: np.ndarray, maxseg: float) -> np.ndarray:
    d = P[1:] - P[:-1]
    L = np.hypot(d[:, 0], d[:, 1])
    n = np.maximum(1, np.ceil(L / maxseg).astype(int))
    idx = np.repeat(np.arange(len(d)), n)
    first = np.cumsum(n) - n
    j = np.arange(n.sum()) - np.repeat(first, n)
    t = (j / n[idx])[:, None]
    pts = P[idx] + d[idx] * t
    return np.vstack([pts, P[-1:]])


def _bisect(kin: Kinematics, good, bad, iters=24):
    lo, hi = np.asarray(good, float), np.asarray(bad, float)
    for _ in range(iters):
        mid = (lo + hi) / 2
        if kin.reachable(mid[0], mid[1]):
            lo = mid
        else:
            hi = mid
    return lo


def clip_to_reach(strokes, kin: Kinematics, maxseg: float):
    """Split strokes at the reachable-region boundary. Returns (runs, clipped_len_mm)."""
    runs, clipped = [], 0.0
    for s in strokes:
        P = densify(s, maxseg)
        ok = kin.reachable(P[:, 0], P[:, 1])
        if ok.all():
            runs.append(P)
            continue
        seglen = np.hypot(*(P[1:] - P[:-1]).T)
        clipped += float(seglen[~(ok[1:] & ok[:-1])].sum())
        i, n = 0, len(P)
        while i < n:
            if not ok[i]:
                i += 1
                continue
            j = i
            while j + 1 < n and ok[j + 1]:
                j += 1
            pts = [P[i:j + 1]]
            if i > 0:
                pts.insert(0, _bisect(kin, P[i], P[i - 1])[None, :])
            if j + 1 < n:
                pts.append(_bisect(kin, P[j], P[j + 1])[None, :])
            run = np.vstack(pts)
            if len(run) >= 2 and np.hypot(*(run[-1] - run[0])) + 1e-12 > 0:
                runs.append(run)
            i = j + 1
    return runs, clipped


def order_and_join(runs, start_xy, join_tol):
    if not runs:
        return []
    n = len(runs)
    S = np.array([r[0] for r in runs])
    E = np.array([r[-1] for r in runs])
    alive = np.ones(n, bool)
    cur = np.asarray(start_xy, float)
    chains: list[list[np.ndarray]] = []
    for _ in range(n):
        ds = np.hypot(S[:, 0] - cur[0], S[:, 1] - cur[1])
        de = np.hypot(E[:, 0] - cur[0], E[:, 1] - cur[1])
        ds[~alive] = np.inf
        de[~alive] = np.inf
        i, j = int(ds.argmin()), int(de.argmin())
        if ds[i] <= de[j]:
            k, rev, gap = i, False, ds[i]
        else:
            k, rev, gap = j, True, de[j]
        alive[k] = False
        pts = runs[k][::-1] if rev else runs[k]
        if chains and gap <= join_tol:
            chains[-1].append(pts[1:] if gap < 1e-9 else pts)
        else:
            chains.append([pts])
        cur = pts[-1]
    return [np.vstack(c) for c in chains]


def subdivide_polar(P: np.ndarray, kin: Kinematics, tol: float, maxseg: float, min_len=0.02):
    """Insert points until motor-linear interpolation stays within `tol` of the chord."""
    pts = densify(P, maxseg)
    for _ in range(16):
        p, q = pts[:-1], pts[1:]
        L = np.hypot(*(q - p).T)
        thp, qp, _ = kin.xy_to_joint(p[:, 0], p[:, 1])
        thq, qq, _ = kin.xy_to_joint(q[:, 0], q[:, 1])
        xm, ym = kin.joint_to_xy((thp + thq) / 2, (qp + qq) / 2)
        err = np.hypot(xm - (p[:, 0] + q[:, 0]) / 2, ym - (p[:, 1] + q[:, 1]) / 2)
        split = (err > tol) & (L > min_len)
        if not split.any():
            break
        idx = np.nonzero(split)[0]
        mids = (p[idx] + q[idx]) / 2
        pts = np.insert(pts, idx + 1, mids, axis=0)
    return pts


# ===========================================================================
# Velocity planning
# ===========================================================================
@dataclass
class DrawPath:
    start: tuple            # (A, B) int steps
    end: tuple
    dA: np.ndarray          # per-segment step deltas (int)
    dB: np.ndarray
    tseg: np.ndarray        # per-segment duration, s
    length_mm: float
    duration_s: float


def plan_draw(P: np.ndarray, kin: Kinematics, cfg: Config) -> DrawPath | None:
    c = cfg.v
    feed = c["motion.draw_speed_mm_s"]
    acc = c["motion.accel_mm_s2"]
    rate = c["motion.max_step_rate_hz"]
    sacc = c["motion.step_accel_hz_s"]
    jerk = c["motion.jerk_hz"]
    dev = c["motion.junction_dev_mm"]

    A, B = kin.xy_to_steps(P[:, 0], P[:, 1])
    Ai, Bi = np.rint(A).astype(np.int64), np.rint(B).astype(np.int64)
    keep = np.ones(len(P), bool)
    keep[1:] = (Ai[1:] != Ai[:-1]) | (Bi[1:] != Bi[:-1])
    # drop points that didn't change the step position (merge into next move)
    Ai, Bi, Q = Ai[keep], Bi[keep], P[keep]
    if len(Q) < 2:
        return None
    dA, dB = np.diff(Ai), np.diff(Bi)
    d = np.diff(Q, axis=0)
    L = np.maximum(np.hypot(d[:, 0], d[:, 1]), 1e-9)
    n = len(L)
    nmax = np.maximum(np.abs(dA), np.abs(dB)).astype(float)
    vlim = np.minimum(feed, rate * L / nmax)
    alim = np.minimum(acc, sacc * L / nmax)

    u = d / L[:, None]
    v = np.empty(n + 1)
    v[0] = v[n] = 0.0
    if n > 1:
        cos_t = -np.einsum("ij,ij->i", u[:-1], u[1:])
        sh = np.sqrt(np.clip((1 - cos_t) / 2, 0, 1))
        with np.errstate(divide="ignore", invalid="ignore"):
            vj = np.where(sh > 0.99999, np.inf, np.sqrt(acc * dev * sh / np.maximum(1 - sh, 1e-12)))
        rA, rB = dA / L, dB / L
        dr = np.maximum(np.abs(rA[1:] - rA[:-1]), np.abs(rB[1:] - rB[:-1]))
        with np.errstate(divide="ignore"):
            vjerk = np.where(dr > 1e-12, jerk / dr, np.inf)
        v[1:n] = np.minimum(np.minimum(vj, vjerk), np.minimum(vlim[:-1], vlim[1:]))
    v[0] = min(vlim[0], jerk * L[0] / nmax[0])
    v[n] = min(vlim[-1], jerk * L[-1] / nmax[-1])

    # backward then forward pass (plain loops; segments are tiny so this is cheap enough)
    vl, Ll, al = v.tolist(), L.tolist(), alim.tolist()
    for i in range(n - 1, -1, -1):
        m = math.sqrt(vl[i + 1] ** 2 + 2 * al[i] * Ll[i])
        if m < vl[i]:
            vl[i] = m
    for i in range(n):
        m = math.sqrt(vl[i] ** 2 + 2 * al[i] * Ll[i])
        if m < vl[i + 1]:
            vl[i + 1] = m
    v = np.maximum(np.array(vl), 0.5)
    tseg = 2 * L / (v[:-1] + v[1:])
    return DrawPath((int(Ai[0]), int(Bi[0])), (int(Ai[-1]), int(Bi[-1])), dA, dB, tseg,
                    float(L.sum()), float(tseg.sum()))


# ===========================================================================
# Motions -> events
# ===========================================================================
@dataclass
class Motion:
    tA: np.ndarray = field(default_factory=lambda: EMPTY_F)
    dirA: np.ndarray = field(default_factory=lambda: EMPTY_I)
    tB: np.ndarray = field(default_factory=lambda: EMPTY_F)
    dirB: np.ndarray = field(default_factory=lambda: EMPTY_I)
    duration: float = 0.0
    net: tuple = (0, 0)


def _events_from_segments(d, tseg):
    n = np.abs(d).astype(np.int64)
    tot = int(n.sum())
    if tot == 0:
        return EMPTY_F, EMPTY_I
    T0 = np.cumsum(tseg) - tseg
    idx = np.repeat(np.arange(len(d)), n)
    first = np.cumsum(n) - n
    j = np.arange(tot) - np.repeat(first, n)
    t = T0[idx] + (j + 0.5) / n[idx] * tseg[idx]
    return t, np.sign(d)[idx].astype(np.int8)


def motion_from_draw(dp: DrawPath) -> Motion:
    tA, sA = _events_from_segments(dp.dA, dp.tseg)
    tB, sB = _events_from_segments(dp.dB, dp.tseg)
    return Motion(tA, sA, tB, sB, dp.duration_s, (int(dp.dA.sum()), int(dp.dB.sum())))


def _trapezoid(N, vmax, a, v0):
    v0 = min(v0, vmax)
    n_acc = (vmax ** 2 - v0 ** 2) / (2 * a)
    if 2 * n_acc >= N:
        vp = math.sqrt(v0 ** 2 + a * N)
        n_acc, t_cruise = N / 2.0, 0.0
    else:
        vp = vmax
        t_cruise = (N - 2 * n_acc) / vmax
    t_acc = (vp - v0) / a
    total = 2 * t_acc + t_cruise

    def t_of_n(nn):
        nn = np.asarray(nn, float)
        acc_part = (-v0 + np.sqrt(v0 ** 2 + 2 * a * np.clip(nn, 0, n_acc))) / a
        dec_n = np.clip(N - nn, 0, n_acc)
        dec_part = total - (-v0 + np.sqrt(v0 ** 2 + 2 * a * dec_n)) / a
        cru = t_acc + (nn - n_acc) / vp
        return np.where(nn <= n_acc, acc_part, np.where(nn >= N - n_acc, dec_part, cru))
    return t_of_n, total


def motion_joint(dA: int, dB: int, vmax_hz: float, accel_hz_s: float, v0_hz: float) -> Motion:
    """Straight move in motor space with a trapezoidal profile on the faster motor."""
    N = max(abs(dA), abs(dB))
    if N == 0:
        return Motion()
    t_of_n, total = _trapezoid(N, vmax_hz, accel_hz_s, v0_hz)

    def ev(d):
        m = abs(d)
        if m == 0:
            return EMPTY_F, EMPTY_I
        nn = (np.arange(m) + 0.5) / m * N
        return t_of_n(nn), np.full(m, np.sign(d), np.int8)
    tA, sA = ev(dA)
    tB, sB = ev(dB)
    return Motion(tA, sA, tB, sB, float(total), (int(dA), int(dB)))


def motion_constant(dA: int, dB: int, rate_hz: float) -> Motion:
    """Constant step rate on the faster motor (homing seeks, short jogs)."""
    N = max(abs(dA), abs(dB))
    if N == 0:
        return Motion()
    total = N / rate_hz

    def ev(d):
        m = abs(d)
        if m == 0:
            return EMPTY_F, EMPTY_I
        return (np.arange(m) + 0.5) / m * total, np.full(m, np.sign(d), np.int8)
    tA, sA = ev(dA)
    tB, sB = ev(dB)
    return Motion(tA, sA, tB, sB, total, (int(dA), int(dB)))


def travel_motion(kin: Kinematics, cfg: Config, fromA, fromB, toA, toB) -> Motion:
    c = cfg.v
    dA, dB = int(toA - fromA), int(toB - fromB)
    N = max(abs(dA), abs(dB))
    if N == 0:
        return Motion()
    x0, y0 = kin.steps_to_xy(fromA, fromB)
    x1, y1 = kin.steps_to_xy(toA, toB)
    Lmm = max(float(np.hypot(x1 - x0, y1 - y0)), 1e-3)
    # Polar moves sweep an arc, so use the larger of chord and steps-implied length
    vmax = min(c["motion.max_step_rate_hz"], c["motion.travel_speed_mm_s"] * N / Lmm)
    acc = min(c["motion.step_accel_hz_s"], c["motion.accel_mm_s2"] * 2 * N / Lmm)
    vmax = max(vmax, 50.0)
    acc = max(acc, 500.0)
    return motion_joint(dA, dB, vmax, acc, min(c["motion.jerk_hz"], vmax))


# ===========================================================================
# Events -> ticks
# ===========================================================================
@dataclass
class Ticks:
    t_us: np.ndarray        # int64, multiples of TICK_US, strictly increasing
    mask: np.ndarray        # uint8  bit0 = step A, bit1 = step B
    dir_a: np.ndarray       # int8 +/-1, direction in force at that event
    dir_b: np.ndarray
    net: tuple              # logical (A, B) step change (excludes backlash take-up)
    duration_s: float
    last_dir: tuple
    lmask: np.ndarray | None = None   # bits of `mask` that are logical (not backlash take-up)

    def cumulative(self):
        """Cumulative logical step counts (A, B) after each tick."""
        lm = self.mask if self.lmask is None else self.lmask
        ca = np.cumsum(np.where(lm & 1, self.dir_a, 0).astype(np.int64))
        cb = np.cumsum(np.where(lm & 2, self.dir_b, 0).astype(np.int64))
        return ca, cb

    def __len__(self):
        return len(self.t_us)


def build_ticks(m: Motion, last_dir=(0, 0), backlash=(0, 0), bl_rate=1500.0) -> Ticks:
    tA, dA, tB, dB = m.tA.copy(), m.dirA, m.tB.copy(), m.dirB
    shiftA = np.zeros(len(tA))
    shiftB = np.zeros(len(tB))
    burst_t, burst_mask, burst_dir = [], [], []
    extra_total = 0.0

    if any(backlash):
        rev_t, rev_delay, rev_m, rev_d = [], [], [], []
        for mi, (t, d) in enumerate(((tA, dA), (tB, dB))):
            bl = backlash[mi]
            if bl <= 0 or len(d) == 0:
                continue
            prev = np.concatenate([[last_dir[mi]], d[:-1]])
            idx = np.nonzero((d != prev) & (prev != 0))[0]
            for i in idx:
                rev_t.append(t[i]); rev_delay.append(bl / bl_rate); rev_m.append(mi); rev_d.append(int(d[i]))
        if rev_t:
            o = np.argsort(rev_t, kind="stable")
            rt = np.array(rev_t)[o]
            rd = np.array(rev_delay)[o]
            rm = np.array(rev_m)[o]
            rdir = np.array(rev_d)[o]
            cum = np.cumsum(rd)
            before = cum - rd
            for arr_t, sh in ((tA, shiftA), (tB, shiftB)):
                k = np.searchsorted(rt, arr_t, side="right")
                sh[:] = np.where(k > 0, cum[np.maximum(k - 1, 0)], 0.0)
            for r in range(len(rt)):
                cnt = int(backlash[rm[r]])
                burst_t.append(rt[r] + before[r] + np.arange(cnt) / bl_rate)
                burst_mask.append(np.full(cnt, 1 << int(rm[r]), np.uint8))
                burst_dir.append(np.full(cnt, rdir[r], np.int8))
            extra_total = float(cum[-1])
    tA = tA + shiftA
    tB = tB + shiftB

    # combine every event: (time, motor bit, direction)
    parts_t = [tA, tB] + burst_t
    parts_m = [np.full(len(tA), 1, np.uint8), np.full(len(tB), 2, np.uint8)] + burst_mask
    parts_d = [dA, dB] + burst_dir
    parts_l = [np.ones(len(tA), np.uint8), np.ones(len(tB), np.uint8)] + [np.zeros(len(b), np.uint8) for b in burst_mask]
    t_all = np.concatenate(parts_t) if parts_t else EMPTY_F
    if len(t_all) == 0:
        return Ticks(np.zeros(0, np.int64), np.zeros(0, np.uint8), EMPTY_I, EMPTY_I, (0, 0), 0.0, tuple(last_dir))
    m_all = np.concatenate(parts_m)
    d_all = np.concatenate(parts_d)
    l_all = np.concatenate(parts_l)

    tb = np.rint(t_all * 1e6 / TICK_US).astype(np.int64) + 1
    # each motor must advance >= 1 tick per step so pulses never merge
    for bit in (1, 2):
        sel = np.nonzero(m_all == bit)[0]
        if len(sel) > 1:
            o = sel[np.argsort(tb[sel], kind="stable")]
            k = np.arange(len(o))
            tb[o] = np.maximum.accumulate(tb[o] - k) + k
    order = np.argsort(tb, kind="stable")
    tb, m_all, d_all, l_all = tb[order], m_all[order], d_all[order], l_all[order]
    starts = np.nonzero(np.concatenate([[True], tb[1:] != tb[:-1]]))[0]
    ut = tb[starts]
    umask = np.bitwise_or.reduceat(m_all, starts)
    ulmask = np.bitwise_or.reduceat((m_all * l_all).astype(np.uint8), starts)
    da = np.where(m_all == 1, d_all, 0).astype(np.int64)
    db = np.where(m_all == 2, d_all, 0).astype(np.int64)
    ga = np.add.reduceat(da, starts)
    gb = np.add.reduceat(db, starts)

    def ffill(g, init):
        idx = np.where(g != 0, np.arange(len(g)), -1)
        idx = np.maximum.accumulate(idx)
        out = np.where(idx >= 0, g[np.maximum(idx, 0)], init if init != 0 else 1)
        return out.astype(np.int8)
    dir_a = ffill(ga, last_dir[0])
    dir_b = ffill(gb, last_dir[1])
    last = (int(dir_a[-1]) if (ga != 0).any() else last_dir[0],
            int(dir_b[-1]) if (gb != 0).any() else last_dir[1])
    dur = float(m.duration + extra_total)
    return Ticks(ut * TICK_US, umask, dir_a, dir_b, m.net, dur, last, ulmask)


# ===========================================================================
# Whole-job plan
# ===========================================================================
@dataclass
class Plan:
    ops: list
    op_times: list              # estimated seconds per op (parallel to ops)
    preview: list               # list of (N,2) drawn polylines (workspace frame)
    travels: list               # list of (x0,y0,x1,y1)
    stats: dict
    warnings: list


def plan_job(strokes, kin: Kinematics, cfg: Config, park_steps=(0, 0)) -> Plan:
    c = cfg.v
    warns: list[str] = []
    maxseg = c["motion.max_segment_mm"]
    runs, clipped = clip_to_reach(strokes, kin, maxseg)
    if clipped > 0.5:
        warns.append(f"{clipped:.0f} mm of the drawing is outside the pen's reachable area and will be skipped.")
    if not runs:
        return Plan([], [], [], [], dict(n_strokes=0, est_time_s=0, clipped_mm=clipped), warns + ["Nothing reachable to draw."])

    px, py = kin.steps_to_xy(*park_steps)
    chains = order_and_join(runs, (float(px), float(py)), c["motion.join_tol_mm"])

    ops: list = []
    op_times: list = []
    preview, travels = [], []
    cur = tuple(int(round(float(v))) for v in park_steps)
    t_total = 0.0
    draw_len = travel_len = 0.0
    settle = c["pen.settle_s"]
    n_seg = 0
    for ch in chains:
        P = subdivide_polar(ch, kin, c["motion.chord_tol_mm"], maxseg)
        dp = plan_draw(P, kin, cfg)
        if dp is None:
            continue
        tm = travel_motion(kin, cfg, cur[0], cur[1], dp.start[0], dp.start[1])
        x0, y0 = kin.steps_to_xy(*cur)
        x1, y1 = kin.steps_to_xy(*dp.start)
        travels.append((float(x0), float(y0), float(x1), float(y1)))
        travel_len += math.hypot(x1 - x0, y1 - y0)
        ops.append(("travel", dp.start)); op_times.append(tm.duration)
        ops.append(("pen", True)); op_times.append(settle)
        ops.append(("draw", dp)); op_times.append(dp.duration_s)
        ops.append(("pen", False)); op_times.append(settle)
        t_total += tm.duration + dp.duration_s + 2 * settle
        draw_len += dp.length_mm
        n_seg += len(dp.tseg)
        preview.append(P)
        cur = dp.end
    tm = travel_motion(kin, cfg, cur[0], cur[1], park_steps[0], park_steps[1])
    ops.append(("travel", tuple(park_steps))); op_times.append(tm.duration)
    t_total += tm.duration
    stats = dict(n_strokes=len(preview), draw_len_mm=draw_len, travel_len_mm=travel_len,
                 est_time_s=t_total, clipped_mm=clipped, segments=n_seg)
    return Plan(ops, op_times, preview, travels, stats, warns)
