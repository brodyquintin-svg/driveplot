"""Differential-swerve kinematics.

Conventions
-----------
* Workspace frame: origin at the pivot axis, +X along the paper's bottom
  edge, +Y up the left edge.  All lengths in mm, angles in radians.
* theta  = arm angle from +X (CCW positive).
* q      = pen extension beyond the home position along the screw (mm).
* phi_A, phi_B = rotation of each side bevel gear, both measured in the same
  sense about their shared axis.  Positive logical motor steps == positive phi.
  (Per-motor wiring inversion is applied at the DIR pin, not here.)

Differential:
    carrier (arm) angle   theta' = ts * (phi_A + phi_B) / 2
    pinion spin vs arm    P      = (phi_A - phi_B) / 2 * (side_pd / pinion_pd)
    screw angle           S      = rs * P * screw_gear_ratio
    extension             q      = lead * S / (2 pi)
"""
from __future__ import annotations

import math

import numpy as np

from .config import Config

TWO_PI = 2.0 * math.pi


class Kinematics:
    def __init__(self, cfg: Config):
        c = cfg.v
        self.spr = c["motors.full_steps_per_rev"] * c["motors.microsteps"]
        self.gA = c["gears.a_driven_pd_mm"] / c["gears.a_drive_pd_mm"]
        self.gB = c["gears.b_driven_pd_mm"] / c["gears.b_drive_pd_mm"]
        self.k = (c["bevel.side_pd_mm"] / c["bevel.pinion_pd_mm"]) * c["screw.gear_ratio"]
        self.lead = c["screw.thread_pitch_mm"] * c["screw.starts"]
        self.ts = float(c["kin.theta_sign"])
        self.rs = float(c["kin.r_sign"])
        self.r_home = c["screw.r_home_mm"]
        self.offset = c["screw.offset_mm"]
        self.travel = c["screw.length_mm"] - c["screw.unusable_mm"]
        self.theta_home = math.radians(c["home.theta_deg"])
        self.theta_min = math.radians(c["limits.theta_min_deg"])
        self.theta_max = math.radians(c["limits.theta_max_deg"])
        self.pivot_to_paper = (c["paper.origin_x_mm"], c["paper.origin_y_mm"])
        # motor steps per radian of side-gear rotation
        self.sA = self.spr * self.gA / TWO_PI
        self.sB = self.spr * self.gB / TWO_PI

    # ---- joint <-> motor steps (relative to the homed position) ----------
    def joint_to_steps(self, theta, q):
        th = np.asarray(theta, dtype=float) - self.theta_home
        S = np.asarray(q, dtype=float) / self.lead * TWO_PI
        d = self.rs * S / self.k
        t = self.ts * th
        return (t + d) * self.sA, (t - d) * self.sB

    def steps_to_joint(self, a, b):
        phiA = np.asarray(a, dtype=float) / self.sA
        phiB = np.asarray(b, dtype=float) / self.sB
        th = self.ts * (phiA + phiB) / 2.0
        S = self.rs * self.k * (phiA - phiB) / 2.0
        return th + self.theta_home, S / TWO_PI * self.lead

    # ---- joint <-> workspace ------------------------------------------------
    def joint_to_xy(self, theta, q):
        a = self.r_home + np.asarray(q, dtype=float)
        ang = np.asarray(theta, dtype=float) + np.arctan2(self.offset, a)
        rho = np.hypot(a, self.offset)
        return rho * np.cos(ang), rho * np.sin(ang)

    def xy_to_joint(self, x, y):
        x = np.asarray(x, dtype=float)
        y = np.asarray(y, dtype=float)
        rho = np.hypot(x, y)
        a2 = rho * rho - self.offset ** 2
        valid = a2 >= 0
        a = np.sqrt(np.where(valid, a2, 0.0))
        theta = np.arctan2(y, x) - np.arctan2(self.offset, a)
        q = a - self.r_home
        return theta, q, valid

    def xy_to_steps(self, x, y):
        th, q, _ = self.xy_to_joint(x, y)
        return self.joint_to_steps(th, q)

    def steps_to_xy(self, a, b):
        th, q = self.steps_to_joint(a, b)
        return self.joint_to_xy(th, q)

    # ---- reach -------------------------------------------------------------
    def reachable(self, x, y, margin=1e-6):
        th, q, valid = self.xy_to_joint(x, y)
        return (valid & (q >= -margin) & (q <= self.travel + margin)
                & (th >= self.theta_min - margin) & (th <= self.theta_max + margin))

    @property
    def r_min(self):
        return math.hypot(self.r_home, self.offset)

    @property
    def r_max(self):
        return math.hypot(self.r_home + self.travel, self.offset)

    # ---- human-readable resolution report ---------------------------------
    def report(self) -> dict:
        dphi = 1.0 / self.sA                 # rad of side-gear per step of A
        dth = dphi                           # A and B each step once, same sense
        dq = self.lead * self.k * dphi / TWO_PI   # A and B each step once, opposite sense
        return dict(
            steps_per_rev_motor=self.spr,
            theta_step_deg=math.degrees(dth),
            r_step_um=dq * 1000.0,
            pen_step_at_rmax_mm=self.r_max * dth,
            lead_mm=self.lead,
            travel_mm=self.travel,
            r_min_mm=self.r_min,
            r_max_mm=self.r_max,
            ratio_a=self.gA, ratio_b=self.gB, screw_k=self.k,
        )
