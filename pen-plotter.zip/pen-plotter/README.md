# Differential-swerve pen plotter controller

Runs on a Raspberry Pi 4. You open a web page on your computer, drop in an SVG or DXF, see exactly where it lands on the paper (and what the pen can't reach), and press **Start drawing**.

## How the machine is modelled

Two stepper motors drive the two side bevel gears of a bevel differential. The pinion between them turns the lead screw; the screw pushes the pen out along the arm.

| Motors turn | What happens |
|---|---|
| Both the same way | The whole arm **swings** (angle θ). The pinion doesn't spin relative to the arm. |
| Opposite ways | The arm holds still and the pinion spins the screw, so the pen **reaches** in or out (extension q). |

The pivot is the origin. +X runs along the paper's bottom edge, +Y up its left edge. A drawing is a set of (x, y) lines; each is cut into short pieces so that moving both motors in a straight line in motor-space stays within `Curve tolerance` (default 0.02 mm) of the true straight line. Then it converts (x, y) → (θ, r) → motor steps and plays them with hardware-timed pulses.

```
phi_A, phi_B = side-gear angles
swing   θ = (phi_A + phi_B) / 2
screw   S = (phi_A - phi_B) / 2 × (side pd / pinion pd) × (screw turns per pinion turn)
reach   q = lead × S / 2π          lead = thread pitch × starts
motor steps = phi × (motor-gear ratio) × (full steps × microsteps) / 2π
```

## Hardware

**Motors:** the 42HBR8021Y-24B-10 datasheet says 1.8° (200 steps/rev), 2.3 A per phase, 1.5 Ω, 2.8 mH, 0.84 N·m. A plotter needs far less than that torque, so set your driver's current limit well below 2.3 A (around 1.0 to 1.5 A is a good start). That keeps the motors and driver cool. Follow your driver board's own instructions for setting the limit.

**Default wiring** (BCM numbers; change any of them in **Setup → Pi pins**):

| Signal | GPIO |
|---|---|
| Motor A STEP / DIR / ENABLE | 17 / 27 / 22 |
| Motor B STEP / DIR / ENABLE | 23 / 24 / 25 |
| Pen servo signal | 26 |
| Swing home switch | 5 |
| Reach home switch | 6 |

* Switches: normally-open, between the GPIO and GND. The Pi's internal pull-ups are used.
* Servo: power it from its own 5 V supply (not the Pi's pin), with grounds tied together.
* Avoid GPIO 12, 13, 18, 19. pigpio uses that hardware for timing.
* Stepper supply (12 to 24 V) must share ground with the Pi. Put a bulk capacitor across the driver supply.
* **Two home switches:** the *swing* switch trips when the arm reaches its home angle; the *reach* switch trips when the screw is fully retracted. Homing finds the reach switch first, then the swing switch. Each switch pins down one of the two independent motions, which together fix both motors.
* The **Emergency stop** button is software. It is not a substitute for being able to cut motor power.

## Install (on the Pi)

Raspberry Pi OS with a Pi 4 (pigpio does **not** work on a Pi 5). Newer Raspberry Pi OS (Debian 13 "trixie") no longer packages pigpio, so `install.sh` builds the pigpio daemon from source when it has to. That needs internet and takes about a minute.

```bash
unzip pen-plotter.zip && cd pen-plotter
./install.sh
.venv/bin/python -m plotter.selftest      # motors stay disabled; checks pigpio + switches
.venv/bin/python -m plotter               # then open the https://… address it prints
```

Your browser will warn about the self-signed certificate (Advanced → Proceed). Connection is encrypted; there's no login unless you add one: `--password something` or `PLOTTER_PASSWORD=...`. Anyone who can reach the page can move the machine, so use it on a network you trust.

To start at boot: `sudo systemctl enable --now pen-plotter`.

Try it with no hardware at all: `python -m plotter --sim` (the simulator starts at a random pose, so you can practice homing).

## Settings (the **Setup** tab)

The placeholder values are **not** your machine's. The page won't let you run a real job until you've pressed **Save settings** once.

| You measure | Field(s) |
|---|---|
| Gear on each motor shaft, and the gear it drives | *Motor A/B gear* and *Gear driven by motor A/B* (pitch diameters; only the ratio matters). Direct drive → same number in both. |
| Side bevel gears and the pinion | *Side bevel gear*, *Pinion bevel gear* |
| Lead screw | *Thread pitch*, *Thread starts* (lead = pitch × starts), *Lead screw length*, *Unusable length* (nut, end blocks, pen holder) |
| Where the pen sits | *Pen distance from pivot at home* (measured when the reach switch trips), *Screw axis sideways offset* (0 if the screw points through the pivot) |
| Stepper setup | *Full steps* (200), *Microstep setting* (must match your driver jumpers) |
| Paper | *Paper width/height*, and *Paper corner X/Y from pivot* (0, 0 if the pivot is exactly on the corner) |

Note on the screw: the **pitch diameter of a lead screw doesn't affect how far it travels**. Only the lead does, so the form asks for pitch and number of starts instead. (T8×2, 4 starts = 8 mm per turn.)

The box at the top of Setup shows what your numbers give you: reach range, and the size of the smallest step at full reach. If "Pen step at full reach" is bigger than you want, use a larger motor-gear ratio or more microsteps.

## First bring-up, in this order

1. **`python -m plotter.selftest`**: confirms pigpio is running, the pulse stream keeps up, and shows each home switch when you press it.
2. **Jog with the pen up and nothing on the paper.** On **Move → Wiring check**, nudge motor A and B. Then use **Jog Swing**:
   * Swing should rotate the whole arm. If the *pen extends* instead, one motor runs backwards: toggle **Invert** for one motor in Setup.
   * If Swing goes the wrong way, flip **Swing direction sign**. If Reach goes the wrong way, flip **Extension direction sign**.
3. **Homing directions:** set *Direction toward swing/reach switch* so the machine moves toward each switch, and *Arm angle at swing switch* to the true angle of the arm there (measured from the paper's bottom edge).
4. Press **Home**. It seeks each switch, backs off, approaches slowly, and sets its position. No switches yet? Move the arm to its home pose by hand and use **Set zero here**.
5. **Draw the calibration example** (100 mm square with circles and diagonals) on real paper. Measure it. A wrong scale means a wrong gear or lead number; a circle that doesn't close, or a square with doubled lines on reversals, means **backlash**: put a few steps into *Backlash motor A/B* and try again.
6. Raise speed and acceleration gradually. If a motor stalls (you'll hear it), lower *Max step rate* or *Step-rate acceleration*. With 12 V supplies, try a max rate around 8000 steps/s.

If a home switch trips when the machine thinks it's far from home, the controller stops, disables the motors and asks you to re-home, because steps were lost.

## Files

* **SVG** (best choice): units are defined, text/curves/transform groups all work. Convert text to paths first (Inkscape: Path → Object to Path).
* **DXF**: lines, arcs, circles, ellipses, polylines, splines, blocks and dimensions. Units come from the file (mm assumed if unset). Text and unsupported entities are skipped and listed as warnings.
* **Placement:** *In reach* (default) picks the largest size and position where the whole drawing is reachable. With the pivot in a corner there's a dead zone around it and a limit at full extension, both hatched on the preview. You can also pick *To paper*, *Actual size* or a custom scale, rotate, mirror, and shift.
* Touching strokes are joined and the drawing order is optimised to cut pen lifts and travel.

## Removing lines, and saving your settings

* **Remove lines or the whole drawing.** On the Job tab, click lines on the sheet to select them (they turn red; click again to deselect), then press *Remove selected* or the Delete key. *Undo* brings back the last batch and *Restore all* brings back everything. *Remove drawing* unloads the file completely. Removed lines are left out of the placement too, so with *In reach* the rest of the drawing may grow to fill the space.
* **Export and load settings.** On the Setup tab, *Export settings* downloads every drive setting (gears, bevels, screw, motors, pins, paper, speeds) as a commented YAML file, including any edits you haven't saved yet. *Load from file* fills the form from such a file so you can check it, and nothing is applied until you press Save. The file leaves out the "reviewed" flag, so a loaded file always has to be saved once before the real machine will run a job. You can also copy an exported file over `config.yaml` on the Pi.

## Layout of the code

```
plotter/config.py       settings schema, validation, YAML
plotter/kinematics.py   (x,y) <-> (θ,r) <-> motor steps
plotter/geometry.py     SVG / DXF loading
plotter/layout.py       fit / rotate / place on paper
plotter/planner.py      reach clipping, ordering, subdivision, velocity planning, step events
plotter/hardware.py     PigpioDriver (DMA pulse streaming) and SimDriver
plotter/machine.py      homing, jog, job run, pause/stop
plotter/server.py       HTTPS + REST API,   plotter/static/  the web page
tests/                  pytest + simulation scripts
```

Run the tests with `python -m pytest tests/test_core.py` (plus `tests/test_variants.py` and `tests/test_pigpio_encoding.py`).

## Honest limits

* The pulse-streaming path (`PigpioDriver`) was tested here against a fake pigpio that decodes the generated pulses back into steps (counts, direction pins and timing all matched), not on a real Pi. `plotter.selftest` exists to catch timing problems on your Pi before any motor moves.
* Everything else (kinematics, homing, planning, job control, the web UI) was exercised end-to-end in the simulator.
* One pen, one pressure. No Z pressure control beyond the servo's two positions.
