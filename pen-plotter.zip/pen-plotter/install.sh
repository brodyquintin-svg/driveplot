#!/usr/bin/env bash
# Raspberry Pi OS (Bullseye/Bookworm) installer for the pen plotter controller.
set -euo pipefail
cd "$(dirname "$0")"

echo "==> System packages"
sudo apt-get update
sudo apt-get install -y python3-venv python3-pip python3-numpy python3-yaml python3-pigpio pigpio openssl

echo "==> pigpio daemon (hardware-timed step pulses)"
sudo systemctl enable --now pigpiod

echo "==> Python environment"
python3 -m venv --system-site-packages .venv
.venv/bin/pip install --upgrade pip
.venv/bin/pip install -r requirements.txt

echo "==> systemd service"
UNIT=/etc/systemd/system/pen-plotter.service
sudo tee "$UNIT" >/dev/null <<UNITEOF
[Unit]
Description=Pen plotter controller
After=network-online.target pigpiod.service
Wants=pigpiod.service

[Service]
User=$USER
WorkingDirectory=$PWD
ExecStart=$PWD/.venv/bin/python -m plotter --config $PWD/config.yaml
Restart=on-failure
Nice=-5

[Install]
WantedBy=multi-user.target
UNITEOF
sudo systemctl daemon-reload

cat <<MSG

Done. Next steps:
  1. Check the wiring and pulse streaming:   .venv/bin/python -m plotter.selftest
  2. Try it without the machine attached:     .venv/bin/python -m plotter --sim
  3. Run for real:                            .venv/bin/python -m plotter
  4. Start on every boot (optional):          sudo systemctl enable --now pen-plotter
Then open https://$(hostname).local:8443 from your computer.
MSG
